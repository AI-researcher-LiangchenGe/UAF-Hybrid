"""
HHAM（分层混合注意力记忆）模块 / HHAM (Hierarchical Hybrid Attentive Memory) Block

本模块实现 HHAM-DRG 架构的核心组件，如论文
"HHAM-DRG: Hierarchical Hybrid Attentive Memory with Dynamic Residual Gating" 所述。

论文中的关键组件：
1. 三级注意力（TLA）：Core、Edge、Null 块，采用不同的计算策略
   / Tri-Level Attention (TLA): Core, Edge, Null blocks with different computation strategies
2. 金字塔 KV 缓存管理器：分层存储，每层具有不同的保留比例
   / Pyramid KV Cache Manager: Hierarchical storage with different retention ratios per layer
3. 动态残差门控（DRG）：基于注意力集中度的自适应混合
   / Dynamic Residual Gating (DRG): Adaptive mixing based on attention concentration

参考：HHAM-DRG 论文，第 3.2-3.4 节 / Reference: HHAM-DRG Paper, Sections 3.2-3.4
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
from typing import Optional, Tuple, Literal
import math


class TriLevelAttention(nn.Module):
    """
    三级注意力（TLA）机制 / Tri-Level Attention (TLA) mechanism.

    将注意力分为三个块：
    / Partitions attention into three blocks:
    - Core 块（前 k_h%）：使用 FlashAttention 的精确计算
      / Core Block (top k_h%): Precise computation with FlashAttention
    - Edge 块（中间）：线性注意力近似
      / Edge Block (middle): Linear attention approximation
    - Null 块（后 k_l%）：跳过（置零）
      / Null Block (bottom k_l%): Skipped (zeroed out)

    Args:
        d_model: 模型维度 / Model dimension
        n_heads: 注意力头数 / Number of attention heads
        k_h: Core 块的高阈值（默认 0.05 = 5%）
            / High threshold for core block (default 0.05 = 5%)
        k_l: Null 块的低阈值（默认 0.10 = 10%）
            / Low threshold for null block (default 0.10 = 10%)
        dropout: Dropout 比率 / Dropout rate

    参考：HHAM-DRG 论文，第 3.2 节，公式 (3) / Reference: HHAM-DRG Paper, Section 3.2, Equation (3)
    """

    def __init__(
        self,
        d_model: int,
        n_heads: int = 8,
        k_h: float = 0.05,
        k_l: float = 0.10,
        dropout: float = 0.0
    ):
        super().__init__()
        assert d_model % n_heads == 0, "d_model must be divisible by n_heads"

        self.d_model = d_model
        self.n_heads = n_heads
        self.d_k = d_model // n_heads
        self.k_h = k_h  # Core 块阈值（前 5%） / Core block threshold (top 5%)
        self.k_l = k_l  # Null 块阈值（后 10%） / Null block threshold (bottom 10%)
        self.scale = math.sqrt(self.d_k)

        # Q、K、V 的线性投影 / Linear projections for Q, K, V
        self.W_q = nn.Linear(d_model, d_model, bias=False)
        self.W_k = nn.Linear(d_model, d_model, bias=False)
        self.W_v = nn.Linear(d_model, d_model, bias=False)
        self.W_o = nn.Linear(d_model, d_model, bias=False)

        # Edge 块输出对齐的投影 / Projection for edge block output alignment
        # 论文第 3.2 节："引入一个可学习的线性投影 Proj(·)"
        # Paper Section 3.2: "introduce a learnable linear projection Proj(·)"
        self.edge_proj = nn.Linear(d_model, d_model, bias=False)

        self.dropout = nn.Dropout(dropout)

    def linear_attention(self, Q: torch.Tensor, K: torch.Tensor, V: torch.Tensor) -> torch.Tensor:
        """
        Edge 块的线性注意力近似 / Linear attention approximation for edge block.

        公式：Output = φ(Q) · (φ(K)^T V) / (φ(Q) · rowsum(φ(K)^T))
        / Formula: Output = φ(Q) · (φ(K)^T V) / (φ(Q) · rowsum(φ(K)^T))

        Args:
            Q: 查询张量，shape (batch, n_heads, seq_len, d_k)
               / Query tensor, shape (batch, n_heads, seq_len, d_k)
            K: 键张量，shape (batch, n_heads, seq_len, d_k)
               / Key tensor, shape (batch, n_heads, seq_len, d_k)
            V: 值张量，shape (batch, n_heads, seq_len, d_k)
               / Value tensor, shape (batch, n_heads, seq_len, d_k)

        Returns:
            输出张量，shape (batch, n_heads, seq_len, d_k)
            / Output tensor, shape (batch, n_heads, seq_len, d_k)

        参考：HHAM-DRG 论文，第 3.2 节，公式 (2) / Reference: HHAM-DRG Paper, Section 3.2, Equation (2)
        """
        # 特征映射 φ(x) = elu(x) + 1（线性注意力的常用选择）
        # Feature map φ(x) = elu(x) + 1 (common choice for linear attention)
        # 【AI不确定，需人工验证】论文未明确指定特征映射函数
        # / [AI uncertain, requires manual verification] Paper does not explicitly specify the feature map function
        phi_Q = F.elu(Q) + 1
        phi_K = F.elu(K) + 1

        # 计算 φ(K)^T V / Compute φ(K)^T V
        KV = torch.matmul(phi_K.transpose(-2, -1), V)  # (batch, n_heads, d_k, d_k)

        # 计算 rowsum(φ(K)^T) / Compute rowsum(φ(K)^T)
        K_sum = phi_K.sum(dim=-2, keepdim=True)  # (batch, n_heads, 1, d_k)

        # 计算分子：φ(Q) · (φ(K)^T V) / Compute numerator: φ(Q) · (φ(K)^T V)
        numerator = torch.matmul(phi_Q, KV)  # (batch, n_heads, seq_len, d_k)

        # 计算分母：φ(Q) · rowsum(φ(K)^T) / Compute denominator: φ(Q) · rowsum(φ(K)^T)
        denominator = torch.matmul(phi_Q, K_sum.transpose(-2, -1))  # (batch, n_heads, seq_len, 1)
        denominator = denominator.clamp(min=1e-6)  # 避免除以零 / Avoid division by zero

        # 输出 / Output
        output = numerator / denominator

        return output

    def forward(self, x: torch.Tensor, mask: Optional[torch.Tensor] = None) -> torch.Tensor:
        """
        实现三级注意力的前向传播 / Forward pass implementing tri-level attention.

        Args:
            x: 输入张量，shape (batch, seq_len, d_model)
               / Input tensor, shape (batch, seq_len, d_model)
            mask: 可选的注意力掩码 / Optional attention mask

        Returns:
            输出张量，shape (batch, seq_len, d_model)
            / Output tensor, shape (batch, seq_len, d_model)

        参考：HHAM-DRG 论文，第 3.2 节，公式 (3) / Reference: HHAM-DRG Paper, Section 3.2, Equation (3)
        """
        batch_size, seq_len, _ = x.shape

        # 计算 Q, K, V / Compute Q, K, V
        Q = self.W_q(x).view(batch_size, seq_len, self.n_heads, self.d_k).transpose(1, 2)
        K = self.W_k(x).view(batch_size, seq_len, self.n_heads, self.d_k).transpose(1, 2)
        V = self.W_v(x).view(batch_size, seq_len, self.n_heads, self.d_k).transpose(1, 2)
        # Q, K, V: (batch, n_heads, seq_len, d_k)

        # 计算注意力分数 / Compute attention scores
        scores = torch.matmul(Q, K.transpose(-2, -1)) / self.scale  # (batch, n_heads, seq_len, seq_len)

        if mask is not None:
            scores = scores.masked_fill(mask == 0, float('-inf'))

        # 计算注意力权重 / Compute attention weights
        attn_weights = F.softmax(scores, dim=-1)  # (batch, n_heads, seq_len, seq_len)

        # 为简化实现，使用每个查询的平均注意力权重来确定 core/edge/null 块
        # For simplicity in this implementation, we use the average attention weight per query
        # to determine core/edge/null blocks
        # 【AI不确定，需人工验证】论文描述的动态分区实现较为复杂，这里采用简化版本
        # / [AI uncertain, requires manual verification] The dynamic partitioning described in the paper is more complex; a simplified version is used here

        # 计算 Core 块输出（标准注意力） / Compute core block output (standard attention)
        core_output = torch.matmul(attn_weights, V)  # (batch, n_heads, seq_len, d_k)

        # 计算 Edge 块输出（线性注意力近似） / Compute edge block output (linear attention approximation)
        edge_output = self.linear_attention(Q, K, V)  # (batch, n_heads, seq_len, d_k)

        # 对 Edge 输出应用投影以对齐 / Apply projection to edge output for alignment
        # 论文："引入一个可学习的线性投影 Proj(·)" / Paper: "introduce a learnable linear projection Proj(·)"
        edge_output = edge_output.transpose(1, 2).contiguous().view(batch_size, seq_len, self.d_model)
        edge_output = self.edge_proj(edge_output)
        edge_output = edge_output.view(batch_size, seq_len, self.n_heads, self.d_k).transpose(1, 2)

        # 合并输出：Core + Edge（Null 贡献为 0）
        # Combine outputs: Core + Edge (Null contributes 0)
        # 论文公式 (3)：Output_TLA = FlashAttention(Core) + Proj(LinearAttention(Edge)) + 0
        # Paper Equation (3): Output_TLA = FlashAttention(Core) + Proj(LinearAttention(Edge)) + 0
        output = core_output + edge_output  # (batch, n_heads, seq_len, d_k)

        # 重塑并投影 / Reshape and project
        output = output.transpose(1, 2).contiguous().view(batch_size, seq_len, self.d_model)
        output = self.W_o(output)
        output = self.dropout(output)

        return output


class DynamicResidualGating(nn.Module):
    """
    动态残差门控（DRG）单元 / Dynamic Residual Gating (DRG) Unit.

    根据注意力集中度动态调整新计算特征与原始输入特征的混合比例。
    / Dynamically adjusts the mixing ratio between newly computed features
    / and original input features based on attention concentration level.

    Args:
        d_model: 模型维度 / Model dimension

    参考：HHAM-DRG 论文，第 3.4 节 / Reference: HHAM-DRG Paper, Section 3.4
    """

    def __init__(self, d_model: int):
        super().__init__()
        self.d_model = d_model

        # 计算动态权重的门控网络 / Gating network to compute dynamic weight
        # 论文："基于当前层注意力分数的集中度（分散度）"
        # Paper: "based on the concentration level (dispersion) of current-layer attention scores"
        self.gate = nn.Sequential(
            nn.Linear(d_model, d_model // 4),
            nn.ReLU(),
            nn.Linear(d_model // 4, 1),
            nn.Sigmoid()
        )

    def forward(self, new_features: torch.Tensor, original_features: torch.Tensor) -> torch.Tensor:
        """
        应用动态残差门控 / Apply dynamic residual gating.

        当注意力高度集中（高置信度）时，更多新特征通过。
        当注意力分散（低置信度）时，保留更多原始特征。
        / When attention is highly focused (high confidence), more new features pass.
        / When attention is dispersed (low confidence), more original features retained.

        Args:
            new_features: 新计算的特征，shape (batch, seq_len, d_model)
                         / New computed features, shape (batch, seq_len, d_model)
            original_features: 原始输入特征，shape (batch, seq_len, d_model)
                             / Original input features, shape (batch, seq_len, d_model)

        Returns:
            门控输出，shape (batch, seq_len, d_model) / Gated output, shape (batch, seq_len, d_model)

        参考：HHAM-DRG 论文，第 3.4 节 / Reference: HHAM-DRG Paper, Section 3.4
        """
        # 基于新特征计算门控权重 / Compute gating weight based on new features
        # 【AI不确定，需人工验证】论文未明确指定门控网络的输入和具体结构
        # / [AI uncertain, requires manual verification] Paper does not explicitly specify the input and exact structure of the gating network
        gate_weight = self.gate(new_features)  # (batch, seq_len, 1)

        # 动态混合：gate_weight * new + (1 - gate_weight) * original
        # Dynamic mixing: gate_weight * new + (1 - gate_weight) * original
        output = gate_weight * new_features + (1 - gate_weight) * original_features

        return output


class PyramidKVCacheManager:
    """
    金字塔 KV 缓存管理器 / Pyramid KV Cache Manager.

    管理分层 KV 存储，每层具有不同的保留比例：
    / Manages hierarchical KV storage with different retention ratios per layer:
    - 较低层（前 L/4）：100% 保留 / Lower layers (first L/4): 100% retention
    - 中下层（L/4 到 L/2）：50% 保留 / Middle-lower layers (L/4 to L/2): 50% retention
    - 中上层（L/2 到 3L/4）：10% 保留 / Middle-upper layers (L/2 to 3L/4): 10% retention
    - 较高层（后 L/4）：5% 保留 / Upper layers (last L/4): 5% retention

    同时维护注意力汇聚 token（前 n_sink 个 token）。
    / Also maintains attention sink tokens (first n_sink tokens).

    Args:
        n_layers: 总层数 / Total number of layers
        n_sink: 始终保留的注意力汇聚 token 数量
               / Number of attention sink tokens to always retain

    参考：HHAM-DRG 论文，第 3.3 节，公式 (4) / Reference: HHAM-DRG Paper, Section 3.3, Equation (4)
    """

    def __init__(self, n_layers: int, n_sink: int = 4):
        self.n_layers = n_layers
        self.n_sink = n_sink

    def get_retention_ratio(self, layer_idx: int) -> float:
        """
        获取给定层的保留比例 / Get the retention ratio for a given layer.

        Args:
            layer_idx: 层索引（从 0 开始） / Layer index (0-based)

        Returns:
            论文中定义的保留比例 r(l) / Retention ratio r(l) as defined in the paper

        参考：HHAM-DRG 论文，第 3.3 节，公式 (4) / Reference: HHAM-DRG Paper, Section 3.3, Equation (4)
        """
        L = self.n_layers
        l = layer_idx + 1  # 转换为从 1 开始的索引 / Convert to 1-based indexing

        if l <= L / 4:
            return 1.0
        elif l <= L / 2:
            return 0.5
        elif l <= 3 * L / 4:
            return 0.1
        else:
            return 0.05

    def select_kv_tokens(
        self,
        K: torch.Tensor,
        V: torch.Tensor,
        layer_idx: int,
        attention_scores: Optional[torch.Tensor] = None
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        """
        基于金字塔策略选择要保留的 KV token。
        / Select which KV tokens to retain based on pyramid strategy.

        Args:
            K: 键张量，shape (batch, seq_len, d_model)
               / Key tensor, shape (batch, seq_len, d_model)
            V: 值张量，shape (batch, seq_len, d_model)
               / Value tensor, shape (batch, seq_len, d_model)
            layer_idx: 当前层索引 / Current layer index
            attention_scores: 可选的注意力分数，用于基于重要性的选择
                            / Optional attention scores for importance-based selection

        Returns:
            选中的 K 和 V 张量 / Selected K and V tensors

        参考：HHAM-DRG 论文，第 3.3 节 / Reference: HHAM-DRG Paper, Section 3.3
        """
        batch_size, seq_len, d_model = K.shape
        ratio = self.get_retention_ratio(layer_idx)
        budget = max(int(seq_len * ratio), self.n_sink)

        # 始终保留汇聚 token（前 n_sink 个 token）
        # Always retain sink tokens (first n_sink tokens)
        # 论文："永久保留前 n_sink 个 token 的完整 KV 状态"
        # Paper: "permanently retain the full KV states of the first n_sink tokens"
        sink_K = K[:, :self.n_sink, :]
        sink_V = V[:, :self.n_sink, :]

        if budget <= self.n_sink:
            return sink_K, sink_V

        # 对于剩余槽位，如果提供了注意力分数则基于注意力分数选择
        # For remaining slots, select based on attention scores if provided
        remaining_budget = budget - self.n_sink

        if attention_scores is not None and remaining_budget > 0:
            # 基于注意力分数选择 top-k token / Select top-k tokens based on attention scores
            # 论文："选择注意力分数最高的 top-k 个非锚点 token"
            # Paper: "selecting the top-k non-anchor tokens with the highest attention scores"
            _, top_indices = torch.topk(attention_scores, remaining_budget, dim=-1)
            selected_K = torch.gather(K, 1, top_indices.unsqueeze(-1).expand(-1, -1, d_model))
            selected_V = torch.gather(V, 1, top_indices.unsqueeze(-1).expand(-1, -1, d_model))

            # 拼接汇聚 token 和选中的 token / Concatenate sink and selected tokens
            K_retained = torch.cat([sink_K, selected_K], dim=1)
            V_retained = torch.cat([sink_V, selected_V], dim=1)
        else:
            # 如果没有注意力分数，直接取前 'budget' 个 token
            # If no attention scores, just take the first 'budget' tokens
            K_retained = K[:, :budget, :]
            V_retained = V[:, :budget, :]

        return K_retained, V_retained


class HHAMBlock(nn.Module):
    """
    分层混合注意力记忆（HHAM）块 / Hierarchical Hybrid Attentive Memory (HHAM) Block.

    将三级注意力、金字塔 KV 缓存管理和动态残差门控
    组合为一个 Transformer 风格的块。
    / Combines Tri-Level Attention, Pyramid KV Cache management, and Dynamic Residual Gating
    / into a single transformer-style block.

    Args:
        d_model: 模型维度 / Model dimension
        n_heads: 注意力头数 / Number of attention heads
        d_ff: 前馈网络维度 / Feed-forward dimension
        dropout: Dropout 比率 / Dropout rate
        layer_idx: 金字塔 KV 管理的层索引 / Layer index for pyramid KV management
        n_layers: 总层数 / Total number of layers

    参考：HHAM-DRG 论文，第 3.1 节 / Reference: HHAM-DRG Paper, Section 3.1
    """

    def __init__(
        self,
        d_model: int,
        n_heads: int = 8,
        d_ff: int = None,
        dropout: float = 0.1,
        layer_idx: int = 0,
        n_layers: int = 12
    ):
        super().__init__()
        self.d_model = d_model
        self.layer_idx = layer_idx

        if d_ff is None:
            d_ff = 4 * d_model

        # 三级注意力 / Tri-Level Attention
        self.attention = TriLevelAttention(d_model, n_heads, dropout=dropout)

        # 前馈网络 / Feed-forward network
        self.ffn = nn.Sequential(
            nn.Linear(d_model, d_ff),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(d_ff, d_model),
            nn.Dropout(dropout)
        )

        # 动态残差门控 / Dynamic Residual Gating
        self.drg_attn = DynamicResidualGating(d_model)
        self.drg_ffn = DynamicResidualGating(d_model)

        # 层归一化 / Layer normalization
        self.norm1 = nn.LayerNorm(d_model)
        self.norm2 = nn.LayerNorm(d_model)

        # 金字塔 KV 缓存管理器 / Pyramid KV Cache Manager
        self.kv_manager = PyramidKVCacheManager(n_layers)

    def forward(self, x: torch.Tensor, mask: Optional[torch.Tensor] = None) -> torch.Tensor:
        """
        HHAM 块的前向传播 / Forward pass through HHAM block.

        Args:
            x: 输入张量，shape (batch, seq_len, d_model)
               / Input tensor, shape (batch, seq_len, d_model)
            mask: 可选的注意力掩码 / Optional attention mask

        Returns:
            输出张量，shape (batch, seq_len, d_model)
            / Output tensor, shape (batch, seq_len, d_model)
        """
        # 带动态残差门控的注意力子层 / Attention sub-layer with dynamic residual gating
        normed = self.norm1(x)
        attn_out = self.attention(normed, mask)
        x = self.drg_attn(attn_out, x)

        # 带动态残差门控的 FFN 子层 / FFN sub-layer with dynamic residual gating
        normed = self.norm2(x)
        ffn_out = self.ffn(normed)
        x = self.drg_ffn(ffn_out, x)

        return x

"""
对齐模块 / Alignment Module

本文件实现蒸馏过程中所有"对齐"相关的模块，包括：
/ This file implements all "alignment" related modules during distillation, including:
1. TokenizerAligner — 教师与学生 tokenizer 的 token ID 空间映射
   / Token ID space mapping between teacher and student tokenizers
2. FeatureProjector — 教师隐藏层特征到学生维度的投影
   / Projection of teacher hidden features to student dimension
3. CrossModalAligner — 视觉-文本跨模态对比学习对齐（InfoNCE）
   / Vision-text cross-modal contrastive alignment (InfoNCE)
4. LogitsAligner — 教师与学生 logits 的词汇表对齐
   / Vocabulary alignment of teacher and student logits
"""

from typing import Dict, List, Optional, Tuple

import torch
import torch.nn as nn
import torch.nn.functional as F


class TokenizerAligner:
    """将教师 tokenizer 的 token ID 空间映射到学生 tokenizer 的 token ID 空间。
    / Maps the teacher tokenizer's token ID space to the student tokenizer's token ID space.

    对于教师词汇表中的每一个 token，通过 decode -> encode 的方式找到其在学生
    词汇表中对应的 token ID。如果学生词汇表中不存在该 token，则映射到 UNK。
    / For each token in the teacher vocabulary, finds its corresponding token ID in the
    / student vocabulary via decode -> encode. If the token does not exist in the student
    / vocabulary, it is mapped to UNK.

    Attributes:
        teacher_tokenizer: 教师模型的分词器 / Teacher model's tokenizer
        student_tokenizer: 学生模型的分词器 / Student model's tokenizer
        alignment_map: 从教师 token ID 到学生 token ID 的映射字典
                       / Mapping dictionary from teacher token ID to student token ID
        student_unk_id: 学生词汇表中 UNK token 的 ID / UNK token ID in student vocabulary
    """

    def __init__(self, teacher_tokenizer, student_tokenizer):
        """初始化 TokenizerAligner / Initialize TokenizerAligner.

        Args:
            teacher_tokenizer: 教师模型的分词器（HuggingFace Tokenizer）
                              / Teacher model's tokenizer (HuggingFace Tokenizer)
            student_tokenizer: 学生模型的分词器（HuggingFace Tokenizer）
                              / Student model's tokenizer (HuggingFace Tokenizer)
        """
        self.teacher_tokenizer = teacher_tokenizer
        self.student_tokenizer = student_tokenizer
        self.alignment_map: Dict[int, int] = {}
        self.student_unk_id = student_tokenizer.unk_token_id if student_tokenizer.unk_token_id is not None else 0
        self._vocab_overlap_count: int = 0
        self._vocab_teacher_only_count: int = 0
        self.build_alignment_map()

    def build_alignment_map(self) -> None:
        """构建从教师 token ID 到学生 token ID 的映射表。
        / Build the mapping table from teacher token IDs to student token IDs.

        遍历教师词汇表中的每一个 token，使用教师 tokenizer.decode() 将 token ID
        还原为文本，再使用学生 tokenizer.encode() 将文本编码为学生 token ID。
        如果学生词汇表中不存在该 token（编码结果为空或仅为特殊 token），则映射到 UNK。
        / Iterates over every token in the teacher vocabulary, uses teacher tokenizer.decode()
        / to restore the token ID to text, then uses student tokenizer.encode() to encode
        / the text into student token IDs. If the token does not exist in the student
        / vocabulary (encoding result is empty or only special tokens), it is mapped to UNK.
        """
        self.alignment_map = {}
        self._vocab_overlap_count = 0
        self._vocab_teacher_only_count = 0

        teacher_vocab_size = self.teacher_tokenizer.vocab_size

        for teacher_id in range(teacher_vocab_size):
            try:
                token_text = self.teacher_tokenizer.decode([teacher_id])
            except Exception:
                self.alignment_map[teacher_id] = self.student_unk_id
                self._vocab_teacher_only_count += 1
                continue

            try:
                student_ids = self.student_tokenizer.encode(token_text, add_special_tokens=False)
            except Exception:
                self.alignment_map[teacher_id] = self.student_unk_id
                self._vocab_teacher_only_count += 1
                continue

            if len(student_ids) == 0:
                self.alignment_map[teacher_id] = self.student_unk_id
                self._vocab_teacher_only_count += 1
            else:
                # 取编码结果的第一个 token 作为映射目标
                # Take the first token of the encoding result as the mapping target
                self.alignment_map[teacher_id] = student_ids[0]
                self._vocab_overlap_count += 1

    def align_token_ids(self, teacher_input_ids: torch.Tensor) -> torch.Tensor:
        """将教师 token IDs 转换为学生 token IDs。
        / Convert teacher token IDs to student token IDs.

        Args:
            teacher_input_ids: 教师的 token ID 张量，shape 为 (batch, seq_len)
                             / Teacher token ID tensor, shape (batch, seq_len)

        Returns:
            对齐后的学生 token ID 张量，shape 为 (batch, seq_len)
            / Aligned student token ID tensor, shape (batch, seq_len)
        """
        device = teacher_input_ids.device
        dtype = teacher_input_ids.dtype
        shape = teacher_input_ids.shape

        # 将映射表转为张量以支持批量查找 / Convert mapping table to tensor for batch lookup
        max_teacher_id = max(self.alignment_map.keys()) + 1
        # 创建查找表，默认值为 student_unk_id / Create lookup table, default value is student_unk_id
        lookup_table = torch.full(
            (max_teacher_id,), self.student_unk_id, dtype=torch.long
        )
        for tid, sid in self.alignment_map.items():
            lookup_table[tid] = sid

        lookup_table = lookup_table.to(device)
        # 将输入展平、查找、再恢复形状 / Flatten input, lookup, then restore shape
        flat_ids = teacher_input_ids.reshape(-1)
        # 处理可能超出查找表范围的 ID / Handle IDs that may exceed the lookup table range
        mask = flat_ids < max_teacher_id
        aligned_flat = torch.where(
            mask,
            lookup_table[flat_ids.clamp(max=max_teacher_id - 1)],
            torch.tensor(self.student_unk_id, device=device, dtype=torch.long)
        )
        return aligned_flat.reshape(shape).to(dtype)

    def get_vocab_overlap_ratio(self) -> float:
        """返回教师与学生词汇表的重叠比例。
        / Return the vocabulary overlap ratio between teacher and student.

        Returns:
            重叠比例，范围 [0, 1]，计算公式为：重叠 token 数 / 教师词汇表大小
            / Overlap ratio, range [0, 1], computed as: overlap count / teacher vocabulary size
        """
        teacher_vocab_size = self.teacher_tokenizer.vocab_size
        if teacher_vocab_size == 0:
            return 0.0
        return self._vocab_overlap_count / teacher_vocab_size

    def get_alignment_stats(self) -> Dict:
        """返回词汇表对齐的统计信息。
        / Return vocabulary alignment statistics.

        Returns:
            包含以下键的字典 / Dictionary containing the following keys:
                - 'teacher_vocab_size': 教师词汇表大小 / Teacher vocabulary size
                - 'student_vocab_size': 学生词汇表大小 / Student vocabulary size
                - 'overlap_count': 重叠 token 数量 / Overlap token count
                - 'teacher_only_count': 教师独有 token 数量 / Teacher-only token count
                - 'overlap_ratio': 重叠比例 / Overlap ratio
        """
        return {
            'teacher_vocab_size': self.teacher_tokenizer.vocab_size,
            'student_vocab_size': self.student_tokenizer.vocab_size,
            'overlap_count': self._vocab_overlap_count,
            'teacher_only_count': self._vocab_teacher_only_count,
            'overlap_ratio': self.get_vocab_overlap_ratio(),
        }


class FeatureProjector(nn.Module):
    """将教师模型的隐藏层特征投影到学生模型的维度。
    / Projects teacher model hidden features to the student model's dimension.

    支持三种投影类型 / Supports three projection types:
    - 'linear': 单层线性投影 + LayerNorm / Single linear projection + LayerNorm
    - 'mlp': 两层 MLP（Linear -> GELU -> Dropout -> Linear）+ LayerNorm
    - 'attention': 交叉注意力机制，学生特征作为 query，教师特征作为 key/value
      / Cross-attention mechanism, student features as query, teacher features as key/value

    Args:
        teacher_dim: 教师模型隐藏层维度 / Teacher model hidden dimension
        student_dim: 学生模型隐藏层维度 / Student model hidden dimension
        projector_type: 投影类型，可选 'linear'、'mlp'、'attention'，默认为 'linear'
                       / Projection type, options: 'linear', 'mlp', 'attention', default 'linear'

    公式 / Formulas:
        linear: y = LayerNorm(Wx + b)
        mlp: y = LayerNorm(W2 * GELU(Dropout(W1 * x + b1)) + b2)
        attention: y = CrossAttention(Q=student, K=teacher, V=teacher)
    """

    def __init__(self, teacher_dim: int, student_dim: int, projector_type: str = 'linear'):
        """初始化 FeatureProjector / Initialize FeatureProjector.

        Args:
            teacher_dim: 教师模型隐藏层维度 / Teacher model hidden dimension
            student_dim: 学生模型隐藏层维度 / Student model hidden dimension
            projector_type: 投影类型，可选 'linear'、'mlp'、'attention'，默认为 'linear'
                           / Projection type, options: 'linear', 'mlp', 'attention', default 'linear'
        """
        super().__init__()
        self.teacher_dim = teacher_dim
        self.student_dim = student_dim
        self.projector_type = projector_type

        if projector_type == 'linear':
            self.proj = nn.Linear(teacher_dim, student_dim)
            self.norm = nn.LayerNorm(student_dim)

        elif projector_type == 'mlp':
            self.proj = nn.Sequential(
                nn.Linear(teacher_dim, student_dim),
                nn.GELU(),
                nn.Dropout(0.1),
                nn.Linear(student_dim, student_dim),
            )
            self.norm = nn.LayerNorm(student_dim)

        elif projector_type == 'attention':
            # 交叉注意力：学生特征作为 query，教师特征作为 key/value
            # Cross-attention: student features as query, teacher features as key/value
            self.cross_attention = nn.MultiheadAttention(
                embed_dim=student_dim,
                num_heads=8,
                kdim=teacher_dim,
                vdim=teacher_dim,
                batch_first=True,
            )
            self.query_proj = nn.Linear(student_dim, student_dim)
            self.norm = nn.LayerNorm(student_dim)

        else:
            raise ValueError(
                f"不支持的投影类型: {projector_type}，"
                f"可选 'linear'、'mlp'、'attention'"
                f" / Unsupported projection type: {projector_type}, "
                f"options: 'linear', 'mlp', 'attention'"
            )

    def forward(
        self,
        student_features: torch.Tensor,
        teacher_features: torch.Tensor,
    ) -> torch.Tensor:
        """前向传播，将教师特征投影到学生维度。
        / Forward pass, project teacher features to student dimension.

        Args:
            student_features: 学生模型特征，shape 为 (batch, seq_len, student_dim)
                            / Student model features, shape (batch, seq_len, student_dim)
            teacher_features: 教师模型特征，shape 为 (batch, seq_len, teacher_dim)
                             / Teacher model features, shape (batch, seq_len, teacher_dim)

        Returns:
            对齐后的特征张量，shape 与 student_features 相同，即 (batch, seq_len, student_dim)
            / Aligned feature tensor, same shape as student_features, i.e., (batch, seq_len, student_dim)
        """
        if self.projector_type == 'linear':
            projected = self.proj(teacher_features)
            return self.norm(projected)

        elif self.projector_type == 'mlp':
            projected = self.proj(teacher_features)
            return self.norm(projected)

        elif self.projector_type == 'attention':
            # 学生特征作为 query，教师特征作为 key/value
            # Student features as query, teacher features as key/value
            query = self.query_proj(student_features)
            attn_output, _ = self.cross_attention(
                query=query,
                key=teacher_features,
                value=teacher_features,
            )
            return self.norm(attn_output)

        else:
            raise ValueError(f"不支持的投影类型: {self.projector_type} / Unsupported projection type: {self.projector_type}")


class CrossModalAligner(nn.Module):
    """视觉-文本跨模态对齐模块，使用 InfoNCE 对比学习损失。
    / Vision-text cross-modal alignment module using InfoNCE contrastive learning loss.

    将视觉特征和文本特征分别通过投影头映射到共享的嵌入空间，
    然后使用 InfoNCE 损失进行对称对比学习。
    / Maps vision and text features to a shared embedding space via projection heads,
    / then performs symmetric contrastive learning using InfoNCE loss.

    Args:
        vision_dim: 视觉特征维度 / Vision feature dimension
        text_dim: 文本特征维度 / Text feature dimension
        shared_dim: 共享嵌入空间维度，默认为 256 / Shared embedding space dimension, default 256
        temperature: InfoNCE 损失的温度参数，默认为 0.07 / InfoNCE loss temperature parameter, default 0.07

    公式 / Formulas:
        sim(v, t) = (v^T * t) / (||v|| * ||t|| * temperature)
        L = -log(exp(sim(v, t+)) / sum_j exp(sim(v, t_j)))
          - log(exp(sim(t, v+)) / sum_i exp(sim(t, v_i)))
    """

    def __init__(
        self,
        vision_dim: int,
        text_dim: int,
        shared_dim: int = 256,
        temperature: float = 0.07,
    ):
        """初始化 CrossModalAligner / Initialize CrossModalAligner.

        Args:
            vision_dim: 视觉特征维度 / Vision feature dimension
            text_dim: 文本特征维度 / Text feature dimension
            shared_dim: 共享嵌入空间维度，默认为 256 / Shared embedding space dimension, default 256
            temperature: InfoNCE 损失的温度参数，默认为 0.07 / InfoNCE loss temperature parameter, default 0.07
        """
        super().__init__()
        self.vision_dim = vision_dim
        self.text_dim = text_dim
        self.shared_dim = shared_dim
        self.temperature = temperature

        # 视觉投影头: Linear -> LayerNorm -> GELU -> Linear
        # Vision projection head: Linear -> LayerNorm -> GELU -> Linear
        self.vision_proj = nn.Sequential(
            nn.Linear(vision_dim, shared_dim),
            nn.LayerNorm(shared_dim),
            nn.GELU(),
            nn.Linear(shared_dim, shared_dim),
        )

        # 文本投影头: Linear -> LayerNorm -> GELU -> Linear
        # Text projection head: Linear -> LayerNorm -> GELU -> Linear
        self.text_proj = nn.Sequential(
            nn.Linear(text_dim, shared_dim),
            nn.LayerNorm(shared_dim),
            nn.GELU(),
            nn.Linear(shared_dim, shared_dim),
        )

    def forward(
        self,
        vision_features: torch.Tensor,
        text_features: torch.Tensor,
    ) -> torch.Tensor:
        """计算视觉-文本 InfoNCE 对比学习损失。
        / Compute vision-text InfoNCE contrastive learning loss.

        如果输入为 3D 张量（包含 token 维度），先在 token 维度做平均池化。
        投影到共享空间后进行 L2 归一化，然后计算对称 InfoNCE 损失。
        / If input is a 3D tensor (with token dimension), average pooling is applied
        / over the token dimension first. After projection to the shared space and
        / L2 normalization, symmetric InfoNCE loss is computed.

        Args:
            vision_features: 视觉特征，shape 为 (batch, vision_dim) 或 (batch, n_vision_tokens, vision_dim)
                            / Vision features, shape (batch, vision_dim) or (batch, n_vision_tokens, vision_dim)
            text_features: 文本特征，shape 为 (batch, text_dim) 或 (batch, seq_len, text_dim)
                          / Text features, shape (batch, text_dim) or (batch, seq_len, text_dim)

        Returns:
            标量 InfoNCE 损失值 / Scalar InfoNCE loss value
        """
        # 如果是 3D 输入，在 token 维度做平均池化 / If 3D input, average pool over token dimension
        if vision_features.dim() == 3:
            vision_features = vision_features.mean(dim=1)
        if text_features.dim() == 3:
            text_features = text_features.mean(dim=1)

        # 投影到共享空间 / Project to shared space
        vision_embeds = self.vision_proj(vision_features)  # (batch, shared_dim)
        text_embeds = self.text_proj(text_features)  # (batch, shared_dim)

        # L2 归一化 / L2 normalization
        vision_embeds = F.normalize(vision_embeds, p=2, dim=-1)
        text_embeds = F.normalize(text_embeds, p=2, dim=-1)

        # 计算相似度矩阵 / Compute similarity matrix: (batch, batch)
        logits = torch.matmul(vision_embeds, text_embeds.T) / self.temperature

        # 对称 InfoNCE 损失 / Symmetric InfoNCE loss
        batch_size = logits.shape[0]
        labels = torch.arange(batch_size, device=logits.device)

        # 视觉到文本方向的损失 / Vision-to-text direction loss
        loss_v2t = F.cross_entropy(logits, labels)

        # 文本到视觉方向的损失 / Text-to-vision direction loss
        loss_t2v = F.cross_entropy(logits.T, labels)

        return (loss_v2t + loss_t2v) / 2.0

    def get_similarities(
        self,
        vision_features: torch.Tensor,
        text_features: torch.Tensor,
    ) -> torch.Tensor:
        """计算视觉特征与文本特征之间的相似度矩阵。
        / Compute the similarity matrix between vision and text features.

        Args:
            vision_features: 视觉特征，shape 为 (batch, vision_dim) 或 (batch, n_vision_tokens, vision_dim)
                            / Vision features, shape (batch, vision_dim) or (batch, n_vision_tokens, vision_dim)
            text_features: 文本特征，shape 为 (batch, text_dim) 或 (batch, seq_len, text_dim)
                          / Text features, shape (batch, text_dim) or (batch, seq_len, text_dim)

        Returns:
            相似度矩阵，shape 为 (batch, batch)，其中元素 (i, j) 表示第 i 个视觉特征
            与第 j 个文本特征之间的余弦相似度
            / Similarity matrix, shape (batch, batch), where element (i, j) represents
            / the cosine similarity between the i-th vision feature and the j-th text feature
        """
        # 如果是 3D 输入，在 token 维度做平均池化 / If 3D input, average pool over token dimension
        if vision_features.dim() == 3:
            vision_features = vision_features.mean(dim=1)
        if text_features.dim() == 3:
            text_features = text_features.mean(dim=1)

        # 投影到共享空间 / Project to shared space
        vision_embeds = self.vision_proj(vision_features)
        text_embeds = self.text_proj(text_features)

        # L2 归一化 / L2 normalization
        vision_embeds = F.normalize(vision_embeds, p=2, dim=-1)
        text_embeds = F.normalize(text_embeds, p=2, dim=-1)

        # 计算相似度矩阵 / Compute similarity matrix
        similarities = torch.matmul(vision_embeds, text_embeds.T)
        return similarities


class LogitsAligner:
    """处理教师和学生词汇表大小不同时的 logits 对齐。
    / Handles logits alignment when teacher and student vocabulary sizes differ.

    当教师和学生的词汇表大小不一致时，需要将教师的 logits 映射到学生的词汇表空间，
    以便计算蒸馏损失。
    / When teacher and student vocabulary sizes are inconsistent, the teacher's logits need
    / to be mapped to the student's vocabulary space for distillation loss computation.

    Args:
        tokenizer_aligner: TokenizerAligner 实例，用于 token ID 映射
                           / TokenizerAligner instance for token ID mapping
        student_vocab_size: 学生词汇表大小 / Student vocabulary size
        teacher_vocab_size: 教师词汇表大小 / Teacher vocabulary size

    公式 / Formula:
        aligned_teacher_logits[b, s, student_id] = teacher_logits[b, s, teacher_id]
        其中 teacher_id -> student_id 由 TokenizerAligner 的映射表决定
        / where teacher_id -> student_id is determined by the TokenizerAligner mapping table
    """

    def __init__(
        self,
        tokenizer_aligner: TokenizerAligner,
        student_vocab_size: int,
        teacher_vocab_size: int,
    ):
        """初始化 LogitsAligner / Initialize LogitsAligner.

        Args:
            tokenizer_aligner: TokenizerAligner 实例，提供 token ID 映射
                              / TokenizerAligner instance providing token ID mapping
            student_vocab_size: 学生词汇表大小 / Student vocabulary size
            teacher_vocab_size: 教师词汇表大小 / Teacher vocabulary size
        """
        self.tokenizer_aligner = tokenizer_aligner
        self.student_vocab_size = student_vocab_size
        self.teacher_vocab_size = teacher_vocab_size

    def remap_teacher_logits(
        self,
        teacher_logits: torch.Tensor,
        teacher_input_ids: torch.Tensor,
    ) -> torch.Tensor:
        """将教师 logits 通过 token 映射对齐到学生词汇表空间。
        / Remap teacher logits to student vocabulary space via token mapping.

        对每个位置的教师 token ID，找到对应的学生 token ID，从教师 logits 中
        取出该位置的值，构建对齐后的 logits。
        / For each position's teacher token ID, find the corresponding student token ID,
        / extract the value at that position from the teacher logits, and construct
        / the aligned logits.

        Args:
            teacher_logits: 教师模型的 logits，shape 为 (batch, seq_len, teacher_vocab_size)
                           / Teacher model logits, shape (batch, seq_len, teacher_vocab_size)
            teacher_input_ids: 教师的原始 token IDs，shape 为 (batch, seq_len)
                              / Teacher's original token IDs, shape (batch, seq_len)

        Returns:
            对齐后的教师 logits，shape 为 (batch, seq_len, student_vocab_size)
            / Aligned teacher logits, shape (batch, seq_len, student_vocab_size)
        """
        batch_size, seq_len, _ = teacher_logits.shape
        device = teacher_logits.device
        dtype = teacher_logits.dtype

        # 初始化对齐后的 logits 为零 / Initialize aligned logits as zeros
        aligned_logits = torch.zeros(
            batch_size, seq_len, self.student_vocab_size,
            device=device, dtype=dtype,
        )

        # 将教师 input_ids 转换为学生 token IDs / Convert teacher input_ids to student token IDs
        student_ids = self.tokenizer_aligner.align_token_ids(teacher_input_ids)

        # 对每个位置，从教师 logits 中取出对应 student_id 位置的值
        # For each position, extract the value at the corresponding student_id from teacher logits
        # teacher_logits[b, s, teacher_input_ids[b, s]] -> aligned_logits[b, s, student_ids[b, s]]
        teacher_token_logits = torch.gather(
            teacher_logits, dim=2, index=teacher_input_ids.unsqueeze(-1)
        ).squeeze(-1)  # (batch, seq_len)

        # 将取出的 logit 值放入对齐后的 logits 中对应的学生 token ID 位置
        # Place the extracted logit values into the aligned logits at the corresponding student token ID positions
        aligned_logits.scatter_(
            dim=2,
            index=student_ids.unsqueeze(-1),
            src=teacher_token_logits.unsqueeze(-1),
        )

        return aligned_logits

    def align_logits(
        self,
        student_logits: torch.Tensor,
        teacher_logits: torch.Tensor,
        teacher_input_ids: torch.Tensor,
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        """将教师 logits 对齐到学生词汇表空间。
        / Align teacher logits to student vocabulary space.

        Args:
            student_logits: 学生模型的 logits，shape 为 (batch, seq_len, student_vocab_size)
                           / Student model logits, shape (batch, seq_len, student_vocab_size)
            teacher_logits: 教师模型的 logits，shape 为 (batch, seq_len, teacher_vocab_size)
                           / Teacher model logits, shape (batch, seq_len, teacher_vocab_size)
            teacher_input_ids: 教师的原始 token IDs，shape 为 (batch, seq_len)
                              / Teacher's original token IDs, shape (batch, seq_len)

        Returns:
            元组 (aligned_student_logits, aligned_teacher_logits)：
            / Tuple (aligned_student_logits, aligned_teacher_logits):
                - aligned_student_logits: 学生 logits，shape 为 (batch, seq_len, student_vocab_size)
                  / Student logits, shape (batch, seq_len, student_vocab_size)
                - aligned_teacher_logits: 对齐后的教师 logits，shape 为 (batch, seq_len, student_vocab_size)
                  / Aligned teacher logits, shape (batch, seq_len, student_vocab_size)
        """
        aligned_teacher_logits = self.remap_teacher_logits(
            teacher_logits, teacher_input_ids
        )
        return student_logits, aligned_teacher_logits

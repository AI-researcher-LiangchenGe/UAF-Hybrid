"""
蒸馏损失函数模块 / Distillation Loss Module

实现多模态蒸馏中的多种损失函数：
/ Implements multiple loss functions for multimodal distillation:
    1. KL 散度损失（软标签蒸馏） / KL divergence loss (soft-label distillation)
    2. 特征对齐损失（隐藏层 L2 损失） / Feature alignment loss (hidden layer L2 loss)
    3. 任务损失（交叉熵） / Task loss (cross-entropy)
    4. 组合蒸馏损失 / Combined distillation loss

Author: AI Assistant
Date: 2026-05-26
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
from typing import Dict, Optional, Tuple


class KLDistillationLoss(nn.Module):
    """
    KL 散度蒸馏损失 / KL divergence distillation loss.

    使用教师模型的软标签（经过温度缩放的概率分布）来指导学生模型。
    / Uses the teacher model's soft labels (temperature-scaled probability distributions) to guide the student model.

    公式：L_KL = T^2 * KL(softmax(z_t/T) || softmax(z_s/T))
    / Formula: L_KL = T^2 * KL(softmax(z_t/T) || softmax(z_s/T))

    Args:
        temperature: 温度参数，控制软标签的平滑程度
                   / Temperature parameter, controls softness of soft labels
        reduction: 降维方式（'batchmean', 'sum', 'mean', 'none'）
                  / Reduction method ('batchmean', 'sum', 'mean', 'none')
    """

    def __init__(self, temperature: float = 2.0, reduction: str = 'batchmean'):
        super().__init__()
        self.temperature = temperature
        self.reduction = reduction
        self.kl_div = nn.KLDivLoss(reduction='none', log_target=False)

    def forward(
        self,
        student_logits: torch.Tensor,
        teacher_logits: torch.Tensor,
        mask: Optional[torch.Tensor] = None
    ) -> torch.Tensor:
        """
        计算 KL 散度损失 / Compute KL divergence loss.

        Args:
            student_logits: 学生模型 logits，shape (batch, seq_len, vocab_size)
                          / Student model logits, shape (batch, seq_len, vocab_size)
            teacher_logits: 教师模型 logits，shape (batch, seq_len, vocab_size)
                          / Teacher model logits, shape (batch, seq_len, vocab_size)
            mask: 掩码，shape (batch, seq_len)，1 表示有效位置
                 / Mask, shape (batch, seq_len), 1 indicates valid position

        Returns:
            KL 散度损失（标量） / KL divergence loss (scalar)
        """
        # 温度缩放 / Temperature scaling
        T = self.temperature
        student_probs = F.log_softmax(student_logits / T, dim=-1)
        teacher_probs = F.softmax(teacher_logits / T, dim=-1)

        # 计算 KL 散度 / Compute KL divergence
        kl = self.kl_div(student_probs, teacher_probs)  # (batch, seq_len, vocab_size)
        kl = kl.sum(dim=-1)  # (batch, seq_len)

        # 应用掩码 / Apply mask
        if mask is not None:
            kl = kl * mask
            loss = kl.sum() / (mask.sum() + 1e-8)
        else:
            if self.reduction == 'batchmean':
                loss = kl.sum() / student_logits.size(0)
            elif self.reduction == 'sum':
                loss = kl.sum()
            elif self.reduction == 'mean':
                loss = kl.mean()
            else:  # 'none'
                loss = kl

        # 乘以 T^2（温度缩放因子） / Multiply by T^2 (temperature scaling factor)
        loss = loss * (T ** 2)

        return loss


class FeatureAlignmentLoss(nn.Module):
    """
    特征对齐损失 / Feature alignment loss.

    对齐学生模型和教师模型的隐藏层特征。
    / Aligns hidden layer features between student and teacher models.

    支持多种距离度量 / Supports multiple distance metrics:
        - 'mse': 均方误差 / Mean squared error
        - 'l2': L2 距离 / L2 distance
        - 'cosine': 余弦距离（1 - 余弦相似度） / Cosine distance (1 - cosine similarity)
        - 'huber': Huber 损失 / Huber loss

    Args:
        distance: 距离度量类型 / Distance metric type
        reduction: 降维方式 / Reduction method
        projection_dim: 投影维度（如果学生和教师维度不同）
                      / Projection dimension (if student and teacher dimensions differ)
    """

    def __init__(
        self,
        distance: str = 'mse',
        reduction: str = 'mean',
        projection_dim: Optional[int] = None
    ):
        super().__init__()
        self.distance = distance
        self.reduction = reduction
        self.projection_dim = projection_dim

        # 如果维度不同，添加投影层 / Add projection layers if dimensions differ
        if projection_dim is not None:
            self.student_proj = nn.Linear(projection_dim[0], projection_dim[1])
            self.teacher_proj = nn.Linear(projection_dim[0], projection_dim[1])
        else:
            self.student_proj = None
            self.teacher_proj = None

    def forward(
        self,
        student_features: torch.Tensor,
        teacher_features: torch.Tensor,
        mask: Optional[torch.Tensor] = None
    ) -> torch.Tensor:
        """
        计算特征对齐损失 / Compute feature alignment loss.

        Args:
            student_features: 学生特征，shape (batch, seq_len, dim) 或 (batch, dim)
                            / Student features, shape (batch, seq_len, dim) or (batch, dim)
            teacher_features: 教师特征，shape (batch, seq_len, dim) 或 (batch, dim)
                            / Teacher features, shape (batch, seq_len, dim) or (batch, dim)
            mask: 掩码，shape (batch, seq_len) 或 (batch,)
                 / Mask, shape (batch, seq_len) or (batch,)

        Returns:
            特征对齐损失（标量） / Feature alignment loss (scalar)
        """
        # 投影（如果需要） / Projection (if needed)
        if self.student_proj is not None:
            student_features = self.student_proj(student_features)
        if self.teacher_proj is not None:
            teacher_features = self.teacher_proj(teacher_features)

        # 计算距离 / Compute distance
        if self.distance == 'mse':
            diff = student_features - teacher_features
            dist = diff ** 2
        elif self.distance == 'l2':
            diff = student_features - teacher_features
            dist = torch.norm(diff, p=2, dim=-1, keepdim=True)
        elif self.distance == 'cosine':
            # 归一化 / Normalize
            student_norm = F.normalize(student_features, p=2, dim=-1)
            teacher_norm = F.normalize(teacher_features, p=2, dim=-1)
            # 余弦相似度 / Cosine similarity
            cosine_sim = (student_norm * teacher_norm).sum(dim=-1, keepdim=True)
            dist = 1 - cosine_sim
        elif self.distance == 'huber':
            diff = student_features - teacher_features
            dist = F.smooth_l1_loss(student_features, teacher_features, reduction='none')
        else:
            raise ValueError(f"未知的距离度量: {self.distance} / Unknown distance metric: {self.distance}")

        # 降维 / Reduce dimensions
        if dist.dim() > 1:
            dist = dist.mean(dim=-1)  # 在特征维度上平均 / Average over feature dimension

        # 应用掩码 / Apply mask
        if mask is not None:
            dist = dist * mask
            loss = dist.sum() / (mask.sum() + 1e-8)
        else:
            if self.reduction == 'mean':
                loss = dist.mean()
            elif self.reduction == 'sum':
                loss = dist.sum()
            else:  # 'none'
                loss = dist

        return loss


class TaskLoss(nn.Module):
    """
    任务损失（交叉熵） / Task loss (cross-entropy).

    使用硬标签（ground truth）计算标准的语言模型损失。
    / Computes standard language model loss using hard labels (ground truth).

    Args:
        ignore_index: 忽略的标签索引 / Ignored label index
        label_smoothing: 标签平滑系数 / Label smoothing coefficient
    """

    def __init__(self, ignore_index: int = -100, label_smoothing: float = 0.0):
        super().__init__()
        self.ignore_index = ignore_index
        self.label_smoothing = label_smoothing
        self.ce_loss = nn.CrossEntropyLoss(
            ignore_index=ignore_index,
            label_smoothing=label_smoothing
        )

    def forward(
        self,
        logits: torch.Tensor,
        labels: torch.Tensor
    ) -> torch.Tensor:
        """
        计算任务损失 / Compute task loss.

        Args:
            logits: 模型输出 logits，shape (batch, seq_len, vocab_size)
                   / Model output logits, shape (batch, seq_len, vocab_size)
            labels: 标签，shape (batch, seq_len) / Labels, shape (batch, seq_len)

        Returns:
            交叉熵损失（标量） / Cross-entropy loss (scalar)
        """
        # 移位以进行因果语言建模 / Shift for causal language modeling
        shift_logits = logits[..., :-1, :].contiguous()
        shift_labels = labels[..., 1:].contiguous()

        # 展平 / Flatten
        shift_logits = shift_logits.view(-1, shift_logits.size(-1))
        shift_labels = shift_labels.view(-1)

        loss = self.ce_loss(shift_logits, shift_labels)
        return loss


class DistillationLoss(nn.Module):
    """
    组合蒸馏损失 / Combined distillation loss.

    组合多种损失：KL 散度 + 特征对齐 + 任务损失
    / Combines multiple losses: KL divergence + feature alignment + task loss

    公式：L_total = λ₁ * L_KL + λ₂ * L_feature + λ₃ * L_task
    / Formula: L_total = λ₁ * L_KL + λ₂ * L_feature + λ₃ * L_task

    Args:
        temperature: 蒸馏温度 / Distillation temperature
        kl_weight: KL 损失权重 / KL loss weight
        feature_weight: 特征对齐损失权重 / Feature alignment loss weight
        task_weight: 任务损失权重 / Task loss weight
        use_kl: 是否使用 KL 损失 / Whether to use KL loss
        use_feature: 是否使用特征对齐损失 / Whether to use feature alignment loss
        use_task: 是否使用任务损失 / Whether to use task loss
    """

    def __init__(
        self,
        temperature: float = 2.0,
        kl_weight: float = 1.0,
        feature_weight: float = 0.5,
        task_weight: float = 0.3,
        use_kl: bool = True,
        use_feature: bool = True,
        use_task: bool = True,
        feature_distance: str = 'mse'
    ):
        super().__init__()
        self.temperature = temperature
        self.kl_weight = kl_weight
        self.feature_weight = feature_weight
        self.task_weight = task_weight
        self.use_kl = use_kl
        self.use_feature = use_feature
        self.use_task = use_task

        # 初始化各个损失模块 / Initialize each loss module
        if use_kl:
            self.kl_loss = KLDistillationLoss(temperature=temperature)
        if use_feature:
            self.feature_loss = FeatureAlignmentLoss(distance=feature_distance)
        if use_task:
            self.task_loss_module = TaskLoss()

    def forward(
        self,
        student_outputs: Dict[str, torch.Tensor],
        teacher_outputs: Optional[Dict[str, torch.Tensor]] = None,
        labels: Optional[torch.Tensor] = None,
        attention_mask: Optional[torch.Tensor] = None
    ) -> Tuple[torch.Tensor, Dict[str, torch.Tensor]]:
        """
        计算组合蒸馏损失 / Compute combined distillation loss.

        Args:
            student_outputs: 学生模型输出，包含 'logits', 'text_features' 等
                            / Student model outputs, containing 'logits', 'text_features', etc.
            teacher_outputs: 教师模型输出，包含 'logits', 'hidden_states' 等
                            / Teacher model outputs, containing 'logits', 'hidden_states', etc.
            labels: 硬标签 / Hard labels
            attention_mask: 注意力掩码 / Attention mask

        Returns:
            total_loss: 总损失 / Total loss
            loss_dict: 包含各个损失分量的字典 / Dictionary containing individual loss components
        """
        loss_dict = {}
        total_loss = 0.0

        # 1. KL 散度损失（软标签） / 1. KL divergence loss (soft labels)
        if self.use_kl and teacher_outputs is not None:
            kl_loss = self.kl_loss(
                student_logits=student_outputs['logits'],
                teacher_logits=teacher_outputs['logits'],
                mask=attention_mask
            )
            weighted_kl = self.kl_weight * kl_loss
            total_loss = total_loss + weighted_kl
            loss_dict['kl_loss'] = kl_loss.item()
            loss_dict['weighted_kl_loss'] = weighted_kl.item()

        # 2. 特征对齐损失 / 2. Feature alignment loss
        if self.use_feature and teacher_outputs is not None:
            # 对齐文本特征 / Align text features
            if 'text_features' in student_outputs and 'hidden_states' in teacher_outputs:
                # 取教师模型的最后一层隐藏状态 / Take the last layer hidden state of the teacher model
                teacher_features = teacher_outputs['hidden_states'][-1]  # (batch, seq_len, dim)
                student_features = student_outputs['text_features']

                # 可能需要对齐序列长度 / May need to align sequence lengths
                min_len = min(student_features.size(1), teacher_features.size(1))
                student_features = student_features[:, :min_len, :]
                teacher_features = teacher_features[:, :min_len, :]

                feature_loss = self.feature_loss(
                    student_features=student_features,
                    teacher_features=teacher_features,
                    mask=attention_mask[:, :min_len] if attention_mask is not None else None
                )
                weighted_feature = self.feature_weight * feature_loss
                total_loss = total_loss + weighted_feature
                loss_dict['feature_loss'] = feature_loss.item()
                loss_dict['weighted_feature_loss'] = weighted_feature.item()

        # 3. 任务损失（硬标签） / 3. Task loss (hard labels)
        if self.use_task and labels is not None:
            task_loss = self.task_loss_module(
                logits=student_outputs['logits'],
                labels=labels
            )
            weighted_task = self.task_weight * task_loss
            total_loss = total_loss + weighted_task
            loss_dict['task_loss'] = task_loss.item()
            loss_dict['weighted_task_loss'] = weighted_task.item()

        loss_dict['total_loss'] = total_loss.item() if isinstance(total_loss, torch.Tensor) else total_loss

        return total_loss, loss_dict

    def update_temperature(self, new_temperature: float):
        """更新蒸馏温度 / Update distillation temperature."""
        self.temperature = new_temperature
        if hasattr(self, 'kl_loss'):
            self.kl_loss.temperature = new_temperature


class TemperatureScheduler:
    """
    温度调度器 / Temperature scheduler.

    在训练过程中动态调整蒸馏温度。
    / Dynamically adjusts the distillation temperature during training.

    支持策略 / Supported strategies:
        - 'linear': 线性退火 / Linear annealing
        - 'cosine': 余弦退火 / Cosine annealing
        - 'constant': 恒定温度 / Constant temperature
        - 'step': 阶梯式下降 / Step-wise decay

    Args:
        initial_temp: 初始温度 / Initial temperature
        final_temp: 最终温度 / Final temperature
        warmup_steps: 预热步数 / Warmup steps
        strategy: 调度策略 / Scheduling strategy
    """

    def __init__(
        self,
        initial_temp: float = 2.0,
        final_temp: float = 1.0,
        warmup_steps: int = 1000,
        strategy: str = 'linear'
    ):
        self.initial_temp = initial_temp
        self.final_temp = final_temp
        self.warmup_steps = warmup_steps
        self.strategy = strategy
        self.current_step = 0

    def step(self) -> float:
        """
        更新温度并返回当前温度 / Update temperature and return current temperature.

        Returns:
            当前温度 / Current temperature
        """
        if self.current_step >= self.warmup_steps:
            return self.final_temp

        progress = self.current_step / self.warmup_steps

        if self.strategy == 'linear':
            temp = self.initial_temp + (self.final_temp - self.initial_temp) * progress
        elif self.strategy == 'cosine':
            import math
            temp = self.final_temp + (self.initial_temp - self.final_temp) * 0.5 * (1 + math.cos(math.pi * progress))
        elif self.strategy == 'step':
            # 在 warmup_steps/2 时下降一半 / Drop by half at warmup_steps/2
            if progress < 0.5:
                temp = self.initial_temp
            else:
                temp = (self.initial_temp + self.final_temp) / 2
        else:  # constant
            temp = self.initial_temp

        self.current_step += 1
        return temp

    def get_current_temp(self) -> float:
        """获取当前温度（不更新步数） / Get current temperature (without updating step count)."""
        if self.current_step >= self.warmup_steps:
            return self.final_temp

        progress = self.current_step / self.warmup_steps

        if self.strategy == 'linear':
            return self.initial_temp + (self.final_temp - self.initial_temp) * progress
        elif self.strategy == 'cosine':
            import math
            return self.final_temp + (self.initial_temp - self.final_temp) * 0.5 * (1 + math.cos(math.pi * progress))
        elif self.strategy == 'step':
            if progress < 0.5:
                return self.initial_temp
            else:
                return (self.initial_temp + self.final_temp) / 2
        else:
            return self.initial_temp


def create_distillation_loss(config: Dict) -> DistillationLoss:
    """
    工厂函数：创建蒸馏损失模块 / Factory function: create distillation loss module.

    Args:
        config: 配置字典 / Configuration dictionary

    Returns:
        DistillationLoss 实例 / DistillationLoss instance
    """
    distill_config = config.get('distillation', {})

    loss = DistillationLoss(
        temperature=distill_config.get('temperature', {}).get('initial', 2.0),
        kl_weight=distill_config.get('loss_weights', {}).get('kl', 1.0),
        feature_weight=distill_config.get('loss_weights', {}).get('feature', 0.5),
        task_weight=distill_config.get('loss_weights', {}).get('task', 0.3),
        use_kl=distill_config.get('use_kl_loss', True),
        use_feature=distill_config.get('use_feature_loss', True),
        use_task=distill_config.get('use_task_loss', True),
        feature_distance='mse'
    )

    return loss

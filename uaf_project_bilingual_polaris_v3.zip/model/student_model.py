"""
多模态学生模型 - 基于 UAF 架构 / Multimodal Student Model - Based on UAF Architecture

将 DeepSeek-V4-Pro（文本教师）和 DINOv3（视觉教师）蒸馏到 UAF 架构中。
Distill DeepSeek-V4-Pro (text teacher) and DINOv3 (vision teacher) into UAF architecture.

模型结构 / Model structure:
    1. 视觉编码器：DINOv3 ViT-S/16（冻结权重）+ 投影层
       / Vision encoder: DINOv3 ViT-S/16 (frozen weights) + projection layer
    2. 文本编码器：UAF_StateIntegrator（6层，d_model=512）
       / Text encoder: UAF_StateIntegrator (6 layers, d_model=512)
    3. 多模态融合：交叉注意力模块 / Multimodal fusion: Cross-attention module
    4. 输出头：LM Head 用于文本生成 / Output head: LM Head for text generation

预估显存占用（T4 16GB）/ Estimated VRAM usage (T4 16GB):
    - 阶段1（文本编码器）：~8GB / Stage 1 (text encoder): ~8GB
    - 阶段2（融合模块）：~10GB / Stage 2 (fusion module): ~10GB
    - 阶段3（端到端）：~14GB / Stage 3 (end-to-end): ~14GB

Author: AI Assistant
Date: 2026-05-26
"""

import torch
import torch.nn as nn
from typing import Optional, Dict, Tuple, Union
import sys
import os

# 添加父目录到路径 / Add parent directory to path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from model.uaf_attention import UAF_StateIntegrator


class VisionEncoder(nn.Module):
    """
    视觉编码器模块 / Vision encoder module.

    使用预训练的 DINOv3 作为骨干网络，添加投影层将特征映射到目标维度。
    / Uses a pretrained DINOv3 as the backbone network, with a projection layer to map features to the target dimension.

    Args:
        backbone: 预训练的 DINOv3 模型 / Pretrained DINOv3 model
        input_dim: DINOv3 输出维度（ViT-S/16 为 384） / DINOv3 output dimension (384 for ViT-S/16)
        hidden_dim: 投影层隐藏维度 / Projection layer hidden dimension
        output_dim: 输出维度（与文本编码器相同，默认 512） / Output dimension (same as text encoder, default 512)
        freeze: 是否冻结 DINOv3 权重 / Whether to freeze DINOv3 weights
    """

    def __init__(
        self,
        backbone: nn.Module,
        input_dim: int = 384,
        hidden_dim: int = 512,
        output_dim: int = 512,
        freeze: bool = True
    ):
        super().__init__()
        self.backbone = backbone
        self.input_dim = input_dim
        self.output_dim = output_dim

        # 冻结 DINOv3 权重 / Freeze DINOv3 weights
        if freeze:
            for param in self.backbone.parameters():
                param.requires_grad = False

        # 投影层：将 DINOv3 特征映射到目标维度
        # Projection layer: map DINOv3 features to target dimension
        self.projection = nn.Sequential(
            nn.Linear(input_dim, hidden_dim),
            nn.LayerNorm(hidden_dim),
            nn.GELU(),
            nn.Dropout(0.1),
            nn.Linear(hidden_dim, output_dim),
            nn.LayerNorm(output_dim)
        )

    def forward(self, pixel_values: torch.Tensor) -> torch.Tensor:
        """
        前向传播 / Forward pass.

        Args:
            pixel_values: 输入图像，shape (batch, channels, height, width)
                        / Input images, shape (batch, channels, height, width)

        Returns:
            视觉特征，shape (batch, output_dim) / Vision features, shape (batch, output_dim)
        """
        with torch.no_grad() if not any(p.requires_grad for p in self.backbone.parameters()) else torch.enable_grad():
            # 使用 DINOv3 提取特征 / Extract features using DINOv3
            outputs = self.backbone(pixel_values)
            # 获取 pooled 特征（class token） / Get pooled features (class token)
            if hasattr(outputs, 'pooler_output'):
                features = outputs.pooler_output  # (batch, input_dim)
            else:
                # 如果没有 pooler_output，使用最后一层的 [CLS] token
                # If no pooler_output, use the [CLS] token from the last layer
                features = outputs.last_hidden_state[:, 0]  # (batch, input_dim)

        # 投影到目标维度 / Project to target dimension
        projected = self.projection(features)  # (batch, output_dim)

        return projected


class CrossAttentionFusion(nn.Module):
    """
    交叉注意力融合模块 / Cross-attention fusion module.

    将视觉特征和文本特征通过交叉注意力进行融合。
    视觉特征作为 query，文本特征作为 key/value。
    / Fuses vision and text features via cross-attention.
    / Vision features as query, text features as key/value.

    Args:
        d_model: 模型维度 / Model dimension
        n_heads: 注意力头数 / Number of attention heads
        dropout: Dropout 概率 / Dropout probability
    """

    def __init__(
        self,
        d_model: int = 512,
        n_heads: int = 8,
        dropout: float = 0.1
    ):
        super().__init__()
        assert d_model % n_heads == 0, "d_model 必须能被 n_heads 整除 / d_model must be divisible by n_heads"

        self.d_model = d_model
        self.n_heads = n_heads
        self.d_k = d_model // n_heads

        # 交叉注意力：视觉 query，文本 key/value
        # Cross-attention: vision query, text key/value
        self.q_proj = nn.Linear(d_model, d_model)
        self.k_proj = nn.Linear(d_model, d_model)
        self.v_proj = nn.Linear(d_model, d_model)
        self.out_proj = nn.Linear(d_model, d_model)

        self.dropout = nn.Dropout(dropout)
        self.scale = self.d_k ** -0.5

    def forward(
        self,
        vision_features: torch.Tensor,
        text_features: torch.Tensor,
        text_mask: Optional[torch.Tensor] = None
    ) -> torch.Tensor:
        """
        前向传播 / Forward pass.

        Args:
            vision_features: 视觉特征，shape (batch, d_model)
                           / Vision features, shape (batch, d_model)
            text_features: 文本特征，shape (batch, seq_len, d_model)
                          / Text features, shape (batch, seq_len, d_model)
            text_mask: 文本掩码，shape (batch, seq_len) / Text mask, shape (batch, seq_len)

        Returns:
            融合特征，shape (batch, d_model) / Fused features, shape (batch, d_model)
        """
        batch_size = vision_features.size(0)

        # 扩展视觉特征维度以适配注意力机制
        # Expand vision features dimension for attention mechanism
        # (batch, d_model) -> (batch, 1, d_model)
        vision_features = vision_features.unsqueeze(1)

        # 计算 Q, K, V / Compute Q, K, V
        Q = self.q_proj(vision_features)  # (batch, 1, d_model)
        K = self.k_proj(text_features)    # (batch, seq_len, d_model)
        V = self.v_proj(text_features)    # (batch, seq_len, d_model)

        # 多头注意力 / Multi-head attention
        Q = Q.view(batch_size, 1, self.n_heads, self.d_k).transpose(1, 2)
        K = K.view(batch_size, -1, self.n_heads, self.d_k).transpose(1, 2)
        V = V.view(batch_size, -1, self.n_heads, self.d_k).transpose(1, 2)
        # Q: (batch, n_heads, 1, d_k)
        # K, V: (batch, n_heads, seq_len, d_k)

        # 注意力分数 / Attention scores
        scores = torch.matmul(Q, K.transpose(-2, -1)) * self.scale
        # (batch, n_heads, 1, seq_len)

        # 应用掩码 / Apply mask
        if text_mask is not None:
            # 扩展掩码维度 / Expand mask dimensions
            mask = text_mask.unsqueeze(1).unsqueeze(2)  # (batch, 1, 1, seq_len)
            scores = scores.masked_fill(mask == 0, float('-inf'))

        attn_weights = torch.softmax(scores, dim=-1)
        attn_weights = self.dropout(attn_weights)

        # 加权求和 / Weighted sum
        attn_output = torch.matmul(attn_weights, V)  # (batch, n_heads, 1, d_k)

        # 合并多头 / Merge multi-heads
        attn_output = attn_output.transpose(1, 2).contiguous().view(batch_size, 1, self.d_model)
        attn_output = attn_output.squeeze(1)  # (batch, d_model)

        # 输出投影 / Output projection
        output = self.out_proj(attn_output)

        return output


class GatedFusion(nn.Module):
    """
    门控融合模块（替代方案） / Gated fusion module (alternative approach).

    使用门控机制融合视觉和文本特征。
    / Uses a gating mechanism to fuse vision and text features.

    Args:
        d_model: 模型维度 / Model dimension
        dropout: Dropout 概率 / Dropout probability
    """

    def __init__(self, d_model: int = 512, dropout: float = 0.1):
        super().__init__()
        self.gate = nn.Sequential(
            nn.Linear(d_model * 2, d_model),
            nn.Sigmoid()
        )
        self.dropout = nn.Dropout(dropout)

    def forward(
        self,
        vision_features: torch.Tensor,
        text_features: torch.Tensor
    ) -> torch.Tensor:
        """
        前向传播 / Forward pass.

        Args:
            vision_features: 视觉特征，shape (batch, d_model)
                           / Vision features, shape (batch, d_model)
            text_features: 文本特征，shape (batch, d_model)（取最后一个位置）
                          / Text features, shape (batch, d_model) (last position)

        Returns:
            融合特征，shape (batch, d_model) / Fused features, shape (batch, d_model)
        """
        # 取文本特征的最后一个位置 / Take the last position of text features
        if text_features.dim() == 3:
            text_features = text_features[:, -1, :]  # (batch, d_model)

        # 拼接特征 / Concatenate features
        concat = torch.cat([vision_features, text_features], dim=-1)  # (batch, d_model*2)

        # 计算门控权重 / Compute gate weights
        gate = self.gate(concat)  # (batch, d_model)

        # 融合 / Fuse
        fused = gate * vision_features + (1 - gate) * text_features
        fused = self.dropout(fused)

        return fused


class MultimodalUAFStudent(nn.Module):
    """
    多模态 UAF 学生模型 / Multimodal UAF student model.

    将视觉和文本模态融合到统一的 UAF 架构中。
    / Fuses vision and text modalities into a unified UAF architecture.

    Args:
        vision_encoder: 视觉编码器 / Vision encoder
        text_d_model: 文本编码器维度 / Text encoder dimension
        text_n_layers: 文本编码器层数 / Text encoder number of layers
        vocab_size: 词汇表大小 / Vocabulary size
        fusion_type: 融合类型（"cross_attention" 或 "gated"）
                    / Fusion type ("cross_attention" or "gated")
        max_seq_length: 最大序列长度 / Maximum sequence length
    """

    def __init__(
        self,
        vision_encoder: nn.Module,
        text_d_model: int = 512,
        text_n_layers: int = 6,
        vocab_size: int = 100000,
        fusion_type: str = "cross_attention",
        max_seq_length: int = 512,
        **uaf_kwargs
    ):
        super().__init__()
        self.text_d_model = text_d_model
        self.vocab_size = vocab_size
        self.fusion_type = fusion_type
        self.max_seq_length = max_seq_length

        # 视觉编码器 / Vision encoder
        self.vision_encoder = vision_encoder

        # 文本嵌入层 / Text embedding layers
        self.token_embedding = nn.Embedding(vocab_size, text_d_model)
        self.pos_embedding = nn.Embedding(max_seq_length, text_d_model)

        # 文本编码器（UAF） / Text encoder (UAF)
        self.text_encoder = UAF_StateIntegrator(
            d_model=text_d_model,
            **uaf_kwargs
        )

        # 多模态融合模块 / Multimodal fusion module
        if fusion_type == "cross_attention":
            self.fusion = CrossAttentionFusion(d_model=text_d_model)
        elif fusion_type == "gated":
            self.fusion = GatedFusion(d_model=text_d_model)
        else:
            raise ValueError(f"未知的融合类型: {fusion_type} / Unknown fusion type: {fusion_type}")

        # 输出头（LM Head） / Output head (LM Head)
        self.lm_head = nn.Sequential(
            nn.LayerNorm(text_d_model),
            nn.Linear(text_d_model, text_d_model),
            nn.GELU(),
            nn.Dropout(0.1),
            nn.Linear(text_d_model, vocab_size)
        )

        # 初始化权重 / Initialize weights
        self._init_weights()

    def _init_weights(self):
        """初始化权重 / Initialize weights."""
        for module in self.modules():
            if isinstance(module, nn.Linear):
                nn.init.xavier_uniform_(module.weight)
                if module.bias is not None:
                    nn.init.zeros_(module.bias)
            elif isinstance(module, nn.Embedding):
                nn.init.normal_(module.weight, std=0.02)

    def forward(
        self,
        input_ids: Optional[torch.Tensor] = None,
        pixel_values: Optional[torch.Tensor] = None,
        attention_mask: Optional[torch.Tensor] = None,
        labels: Optional[torch.Tensor] = None,
        return_hidden_states: bool = False
    ) -> Dict[str, torch.Tensor]:
        """
        前向传播 / Forward pass.

        Args:
            input_ids: 输入 token IDs，shape (batch, seq_len)
                      / Input token IDs, shape (batch, seq_len)
            pixel_values: 输入图像，shape (batch, channels, height, width)
                        / Input images, shape (batch, channels, height, width)
            attention_mask: 注意力掩码，shape (batch, seq_len)
                          / Attention mask, shape (batch, seq_len)
            labels: 标签（用于计算损失），shape (batch, seq_len)
                   / Labels (for loss computation), shape (batch, seq_len)
            return_hidden_states: 是否返回隐藏状态 / Whether to return hidden states

        Returns:
            包含 logits 和可选隐藏状态的字典
            / Dictionary containing logits and optional hidden states
        """
        outputs = {}

        # 编码视觉特征 / Encode vision features
        if pixel_values is not None:
            vision_features = self.vision_encoder(pixel_values)
            outputs['vision_features'] = vision_features
        else:
            vision_features = None

        # 编码文本特征 / Encode text features
        if input_ids is not None:
            batch_size, seq_len = input_ids.shape

            # 嵌入 / Embeddings
            token_embeds = self.token_embedding(input_ids)
            pos_ids = torch.arange(seq_len, device=input_ids.device).unsqueeze(0).expand(batch_size, -1)
            pos_embeds = self.pos_embedding(pos_ids)
            text_embeds = token_embeds + pos_embeds

            # UAF 编码 / UAF encoding
            text_features = self.text_encoder(text_embeds)
            outputs['text_features'] = text_features

            # 多模态融合 / Multimodal fusion
            if vision_features is not None:
                if self.fusion_type == "cross_attention":
                    fused_features = self.fusion(vision_features, text_features, attention_mask)
                else:  # gated
                    fused_features = self.fusion(vision_features, text_features)
                outputs['fused_features'] = fused_features

                # 将融合特征与文本特征结合（简单相加）
                # Combine fused features with text features (simple addition)
                # 扩展融合特征维度以匹配文本特征
                # Expand fused features dimension to match text features
                fused_features = fused_features.unsqueeze(1).expand(-1, seq_len, -1)
                combined_features = text_features + fused_features
            else:
                combined_features = text_features

            # LM Head
            logits = self.lm_head(combined_features)
            outputs['logits'] = logits

            # 计算损失 / Compute loss
            if labels is not None:
                loss_fct = nn.CrossEntropyLoss(ignore_index=-100)
                shift_logits = logits[..., :-1, :].contiguous()
                shift_labels = labels[..., 1:].contiguous()
                loss = loss_fct(shift_logits.view(-1, self.vocab_size), shift_labels.view(-1))
                outputs['loss'] = loss

        return outputs

    def generate(
        self,
        pixel_values: Optional[torch.Tensor] = None,
        input_ids: Optional[torch.Tensor] = None,
        attention_mask: Optional[torch.Tensor] = None,
        max_new_tokens: int = 100,
        temperature: float = 1.0,
        top_k: int = 50,
        top_p: float = 0.95,
        do_sample: bool = True,
        eos_token_id: int = 2,
        pad_token_id: int = 0
    ) -> torch.Tensor:
        """
        自回归生成 / Autoregressive generation.

        Args:
            pixel_values: 输入图像 / Input images
            input_ids: 输入 token IDs / Input token IDs
            attention_mask: 注意力掩码 / Attention mask
            max_new_tokens: 最大生成 token 数 / Maximum number of new tokens to generate
            temperature: 采样温度 / Sampling temperature
            top_k: Top-k 采样 / Top-k sampling
            top_p: Top-p (nucleus) 采样 / Top-p (nucleus) sampling
            do_sample: 是否采样 / Whether to sample
            eos_token_id: 结束 token ID / End-of-sequence token ID
            pad_token_id: 填充 token ID / Padding token ID

        Returns:
            生成的 token IDs / Generated token IDs
        """
        self.eval()

        if input_ids is None:
            # 从 BOS token 开始 / Start from BOS token
            batch_size = pixel_values.size(0) if pixel_values is not None else 1
            input_ids = torch.full((batch_size, 1), pad_token_id, device=next(self.parameters()).device)
            attention_mask = torch.ones_like(input_ids)

        with torch.no_grad():
            for _ in range(max_new_tokens):
                # 前向传播 / Forward pass
                outputs = self.forward(
                    input_ids=input_ids,
                    pixel_values=pixel_values,
                    attention_mask=attention_mask
                )

                logits = outputs['logits'][:, -1, :]  # 取最后一个位置 / Take last position
                logits = logits / temperature

                # Top-k 过滤 / Top-k filtering
                if top_k > 0:
                    indices_to_remove = logits < torch.topk(logits, top_k)[0][..., -1, None]
                    logits[indices_to_remove] = float('-inf')

                # Top-p 过滤 / Top-p filtering
                if top_p < 1.0:
                    sorted_logits, sorted_indices = torch.sort(logits, descending=True)
                    cumulative_probs = torch.cumsum(torch.softmax(sorted_logits, dim=-1), dim=-1)
                    sorted_indices_to_remove = cumulative_probs > top_p
                    sorted_indices_to_remove[..., 1:] = sorted_indices_to_remove[..., :-1].clone()
                    sorted_indices_to_remove[..., 0] = 0
                    indices_to_remove = sorted_indices_to_remove.scatter(1, sorted_indices, sorted_indices_to_remove)
                    logits[indices_to_remove] = float('-inf')

                # 采样 / Sampling
                if do_sample:
                    probs = torch.softmax(logits, dim=-1)
                    next_token = torch.multinomial(probs, num_samples=1)
                else:
                    next_token = torch.argmax(logits, dim=-1, keepdim=True)

                # 追加到序列 / Append to sequence
                input_ids = torch.cat([input_ids, next_token], dim=1)
                attention_mask = torch.cat([attention_mask, torch.ones_like(next_token)], dim=1)

                # 检查是否生成 EOS / Check if EOS is generated
                if (next_token == eos_token_id).all():
                    break

        return input_ids

    def freeze_vision_encoder(self):
        """冻结视觉编码器 / Freeze vision encoder."""
        for param in self.vision_encoder.parameters():
            param.requires_grad = False

    def freeze_text_encoder(self):
        """冻结文本编码器 / Freeze text encoder."""
        for param in self.text_encoder.parameters():
            param.requires_grad = False
        for param in self.token_embedding.parameters():
            param.requires_grad = False
        for param in self.pos_embedding.parameters():
            param.requires_grad = False

    def freeze_fusion_module(self):
        """冻结融合模块 / Freeze fusion module."""
        for param in self.fusion.parameters():
            param.requires_grad = False

    def unfreeze_all(self):
        """解冻所有参数 / Unfreeze all parameters."""
        for param in self.parameters():
            param.requires_grad = True


def create_student_model(
    vision_backbone: nn.Module,
    config: Dict
) -> MultimodalUAFStudent:
    """
    工厂函数：创建学生模型 / Factory function: create student model.

    Args:
        vision_backbone: 预训练的视觉骨干模型（如 DINOv3）
                        / Pretrained vision backbone model (e.g., DINOv3)
        config: 配置字典 / Configuration dictionary

    Returns:
        MultimodalUAFStudent 实例 / MultimodalUAFStudent instance
    """
    vision_config = config.get('student_model', {}).get('vision_encoder', {})
    text_config = config.get('student_model', {}).get('text_encoder', {})
    fusion_config = config.get('student_model', {}).get('fusion', {})
    output_config = config.get('student_model', {}).get('output_head', {})

    # 创建视觉编码器 / Create vision encoder
    vision_encoder = VisionEncoder(
        backbone=vision_backbone,
        input_dim=vision_config.get('input_dim', 384),
        hidden_dim=vision_config.get('hidden_dim', 512),
        output_dim=vision_config.get('output_dim', 512),
        freeze=vision_config.get('freeze', True)
    )

    # 创建多模态学生模型 / Create multimodal student model
    model = MultimodalUAFStudent(
        vision_encoder=vision_encoder,
        text_d_model=text_config.get('d_model', 512),
        text_n_layers=text_config.get('n_layers', 6),
        vocab_size=output_config.get('vocab_size', 100000),
        fusion_type=fusion_config.get('type', 'cross_attention'),
        max_seq_length=config.get('data', {}).get('train_dataset', {}).get('max_seq_length', 512),
        eta=text_config.get('eta', 1.0),
        activation=text_config.get('activation', 'relu')
    )

    return model

# UAF 多模态蒸馏项目 / UAF Multimodal Distillation Project

将 DeepSeek-V4-Pro（文本教师）和 DINOv3（视觉教师）蒸馏到 UAF（Unnormalized Attention Flow）架构中，构建轻量级多模态大模型。项目包含论文公式的严格实现、四重对齐蒸馏策略、完整的理论验证和单元测试。

Distilling DeepSeek-V4-Pro (text teacher) and DINOv3 (vision teacher) into the UAF (Unnormalized Attention Flow) architecture to build a lightweight multimodal large model. The project includes rigorous implementation of paper formulas, a quadruple-alignment distillation strategy, comprehensive theoretical verification, and unit tests.

---

## 目录 / Table of Contents

- [项目结构 / Project Structure](#项目结构--project-structure)
- [核心公式 / Core Formulas](#核心公式--core-formulas)
- [蒸馏架构 / Distillation Architecture](#蒸馏架构--distillation-architecture)
- [四重对齐策略 / Quadruple Alignment Strategy](#四重对齐策略--quadruple-alignment-strategy)
- [环境要求 / Environment Requirements](#环境要求--environment-requirements)
- [快速开始 / Quick Start](#快速开始--quick-start)
- [详细使用说明 / Detailed Usage Guide](#详细使用说明--detailed-usage-guide)
- [验证与测试 / Verification and Testing](#验证与测试--verification-and-testing)
- [配置说明 / Configuration Guide](#配置说明--configuration-guide)
- [教师模型信息 / Teacher Model Information](#教师模型信息--teacher-model-information)
- [已知限制与待验证项 / Known Limitations and Pending Items](#已知限制与待验证项--known-limitations-and-pending-items)
- [论文引用 / Paper References](#论文引用--paper-references)

---

## 项目结构 / Project Structure

```
uaf_project/
├── model/
│   ├── __init__.py
│   ├── uaf_attention.py       # UAF 核心模块（论文 Section 4.2 严格实现）
│   ├── hham_block.py          # HHAM-DRG 模块（三级注意力 + 金字塔 KV 缓存）
│   ├── student_model.py       # 多模态学生模型（视觉编码器 + UAF 文本编码器 + 融合）
│   ├── distill_loss.py        # 蒸馏损失函数（KL + 特征对齐 + 任务损失 + 温度调度）
│   └── alignment.py           # 四重对齐模块（Token / 特征 / Logits / 跨模态）
├── trainer/
│   ├── __init__.py
│   ├── train.py               # 基础训练脚本（UAF / HHAM 单模态）
│   ├── train_distill.py       # 多模态蒸馏训练主脚本（完整版，含四重对齐）
│   ├── data_loader.py         # 多模态数据加载器（JSONL / Dummy）
│   ├── distill_config.yaml    # 蒸馏超参数配置
│   ├── analyze_results.py     # 训练结果分析（损失曲线 + 报告生成）
│   └── report_template.md     # 实验报告模板
├── tests/
│   ├── __init__.py
│   ├── test_uaf.py            # UAF 核心单元测试（12 个）
│   └── test_distill.py        # 蒸馏相关单元测试（26 个）
├── verification/
│   └── verify_theorem.py      # 注意力稀释定理数值验证
├── requirements.txt
├── run_distill.sh             # 一键启动蒸馏脚本
└── README.md
```

---

## 核心公式 / Core Formulas

### UAF 状态演化机制（论文 Section 4.2） / UAF State Evolution Mechanism (Paper Section 4.2)

**强度函数**（Section 4.1）：

**Intensity Function** (Section 4.1):

```
α(q, k) = σ(q^T k) · ||k||
```

σ(·) 是非负激活函数（ReLU 或 SiLU），||k|| 是 key 向量的 L2 范数。

σ(·) is a non-negative activation function (ReLU or SiLU), and ||k|| is the L2 norm of the key vector.

**连续 ODE**：

**Continuous ODE**:

```
ż(t) = α(q(t), k(t)) · v(t),  z(0) = 0
```

**离散更新规则**（Equation 4）：

**Discrete Update Rule** (Equation 4):

```
z_i = z_{i-1} + η · α(q_i, k_i) · v_i,  z_0 = 0
```

**输出**（Section 4.3）：

**Output** (Section 4.3):

```
y_i = LayerNorm(z_i)
```

### 注意力稀释定理（论文 Section 3.1） / Attention Dilution Theorem (Paper Section 3.1)

```
lim_{n→∞} max_{1≤i≤n} a_i = 0  (almost surely)
E[max_{1≤i≤n} a_i] ≤ C / log(n)
```

---

## 蒸馏架构 / Distillation Architecture

```
┌───────────────────────────────────────────────────────────────┐
│                     多模态蒸馏架构                              │
├───────────────────────────────────────────────────────────────┤
│                                                               │
│  ┌─────────────────────┐    ┌─────────────────────────┐      │
│  │  文本教师            │    │  视觉教师                │      │
│  │  DeepSeek-V4-Pro     │    │  DINOv3 ViT-S/16       │      │
│  │  (1.6T, 49B 激活)    │    │  (21M, 冻结)           │      │
│  └────────┬────────────┘    └──────────┬──────────────┘      │
│           │                            │                       │
│           │  ┌─────────────────────────┘                       │
│           │  │                                                  │
│           ▼  ▼                                                  │
│  ┌─────────────────────────────────────────────┐              │
│  │          四重对齐 (Alignment)                 │              │
│  │                                              │              │
│  │  [1] Token 空间对齐   TokenizerAligner       │              │
│  │  [2] 特征维度对齐     FeatureProjector (MLP) │              │
│  │  [3] Logits 分布对齐   LogitsAligner + KL     │              │
│  │  [4] 视觉-文本对齐     CrossModalAligner      │              │
│  │      (InfoNCE 对比学习)                        │              │
│  └────────────────────┬─────────────────────────┘              │
│                       │                                         │
│                       ▼                                         │
│  ┌─────────────────────────────────────────────┐              │
│  │          学生模型 (MultimodalUAFStudent)      │              │
│  │                                              │              │
│  │  视觉编码器: DINOv3 + 投影层 (384→512)       │              │
│  │  文本编码器: UAF_StateIntegrator (6层, 512d)  │              │
│  │  融合模块:   交叉注意力                       │              │
│  │  输出头:     LM Head (→ vocab_size)          │              │
│  └─────────────────────────────────────────────┘              │
└───────────────────────────────────────────────────────────────┘
```

---

## 四重对齐策略 / Quadruple Alignment Strategy

### 总损失公式 / Total Loss Formula

```
L_total = λ₁ · L_KL + λ₂ · L_feature + λ₃ · L_task + λ₄ · L_cross_modal
        = 1.0 · KL  + 0.5 · MSE    + 0.3 · CE    + 0.2 · InfoNCE
```

| # | 对齐类型 / Alignment Type | 模块 / Module | 原理 / Principle | 权重 / Weight |
|---|---------|------|------|------|
| 1 | **Token 空间对齐** | `TokenizerAligner` | 教师 tokenizer → 学生 tokenizer 的 decode→encode 映射 | — |
| 2 | **特征维度对齐** | `FeatureProjector` | 教师 hidden (4096d) → 学生 (512d) 的 MLP 投影 | λ₂=0.5 |
| 3 | **Logits 分布对齐** | `LogitsAligner` + KL 散度 | 教师 logits 通过 token 映射对齐到学生词汇表空间，温度缩放后计算 KL | λ₁=1.0 |
| 4 | **视觉-文本跨模态对齐** | `CrossModalAligner` | DINOv3 视觉特征与 UAF 文本状态的 InfoNCE 对比学习 | λ₄=0.2 |

### 温度调度 / Temperature Scheduling

蒸馏温度从 T=2.0 线性退火到 T=1.0，在 warmup_steps 步内完成。

The distillation temperature linearly anneals from T=2.0 to T=1.0 over warmup_steps steps.

---

## 环境要求 / Environment Requirements

### 硬件 / Hardware

- **最低**: NVIDIA T4 (16GB 显存)
- **推荐**: NVIDIA A100 (40GB+)
- **CPU 模式**: 支持（极慢，仅用于调试）

- **Minimum**: NVIDIA T4 (16GB VRAM)
- **Recommended**: NVIDIA A100 (40GB+)
- **CPU Mode**: Supported (extremely slow, for debugging only)

### 软件 / Software

```
Python >= 3.9
PyTorch >= 2.0.0
Transformers >= 4.35.0
ModelScope
torchvision
numpy >= 1.24.0
pytest >= 7.0.0
matplotlib >= 3.7.0
scipy >= 1.10.0
pyyaml
safetensors (可选，用于安全格式保存)
```

### 安装 / Installation

```bash
pip install -r requirements.txt
```

---

## 快速开始 / Quick Start

### 1. 验证 UAF 核心实现 / Verify UAF Core Implementation

```bash
# 运行理论验证（注意力稀释定理 + 状态积分）
python verification/verify_theorem.py

# 运行单元测试
pytest tests/ -v
```

### 2. Dry-run 蒸馏流程（无需 GPU / 真实模型） / Dry-run Distillation Pipeline (No GPU / Real Models Required)

```bash
python trainer/train_distill.py --dry-run
```

这会使用模拟教师模型和随机数据跑通整个蒸馏流程（前向 → 四重对齐 → 反向 → 保存），验证代码逻辑正确性。

This runs the entire distillation pipeline (forward → quadruple alignment → backward → save) using simulated teacher models and random data, verifying code logic correctness.

### 3. 一键启动真实蒸馏 / One-Click Real Distillation Launch

```bash
bash run_distill.sh
```

支持参数：

Supported parameters:

```bash
bash run_distill.sh --config trainer/distill_config.yaml   # 指定配置
bash run_distill.sh --resume outputs/checkpoint-1000.pt     # 恢复训练
bash run_distill.sh --stage 1                                # 从阶段 1 开始
```

### 4. 分析训练结果 / Analyze Training Results

```bash
python trainer/analyze_results.py \
    --log outputs/distill_uaf_multimodal/training_log.csv \
    --output-dir outputs/analysis
```

---

## 详细使用说明 / Detailed Usage Guide

### UAF_StateIntegrator

```python
from model.uaf_attention import UAF_StateIntegrator
import torch

uaf = UAF_StateIntegrator(d_model=512, eta=1.0, activation='relu')

# 训练模式（向量化，O(N) 复杂度）
x = torch.randn(2, 10, 512)
output = uaf(x)  # (2, 10, 512)

# 推理模式（逐步，O(1) 每步）
state = None
for i in range(10):
    output, state = uaf.inference_step(x[:, i, :], state)
```

### 多模态学生模型 / Multimodal Student Model

```python
from model.student_model import create_student_model

# vision_backbone 为预训练的 DINOv3 模型
student = create_student_model(vision_backbone, config)

# 前向传播
outputs = student(
    input_ids=input_ids,       # (batch, seq_len)
    pixel_values=images,       # (batch, 3, 224, 224)
    attention_mask=mask,       # (batch, seq_len)
    labels=labels,             # (batch, seq_len)
)
# outputs['logits'], outputs['loss'], outputs['vision_features'], ...

# 自回归生成
generated = student.generate(pixel_values=images, max_new_tokens=100)
```

### 对齐模块独立使用 / Standalone Alignment Module Usage

```python
from model.alignment import FeatureProjector, CrossModalAligner

# 特征维度对齐
projector = FeatureProjector(teacher_dim=4096, student_dim=512, projector_type='mlp')
aligned = projector(student_features, teacher_features)

# 视觉-文本对比学习
aligner = CrossModalAligner(vision_dim=512, text_dim=512, shared_dim=256)
loss = aligner(vision_features, text_features)  # InfoNCE loss
```

---

## 验证与测试 / Verification and Testing

### 测试结果 / Test Results

| 测试文件 / Test File | 通过 / Passed | 跳过 / Skipped | 总计 / Total |
|---------|------|------|------|
| `tests/test_uaf.py` | 12 | 0 | 12 |
| `tests/test_distill.py` | 25 | 1 | 26 |
| **合计 / Total** | **37** | **1** | **38** |

### 理论验证结果 / Theoretical Verification Results

| 验证项 / Verification Item | 状态 / Status | 说明 / Description |
|--------|------|------|
| 注意力稀释定理 | ✓ 通过 | max a_i 随 n 增大趋于零，衰减符合 O(1/log n) |
| UAF 向量化与循环一致性 | ✓ 通过 | 误差 < 1e-5 |
| 状态范数单调性 | ✓ 通过 | 总体增长趋势 |
| DRY-RUN 完整流程 | ✓ 通过 | 前向 + 四重对齐 + 反向 + 保存 |
| AI 自我审视 | ✓ 完成 | UAF 核心实现 0 处不确定 |

### 运行全部验证 / Run All Verifications

```bash
# 语法检查
find . -name '*.py' -exec python -m py_compile {} \;

# 单元测试
pytest tests/ -v

# 理论验证
python verification/verify_theorem.py
```

---

## 配置说明 / Configuration Guide

所有超参数在 `trainer/distill_config.yaml` 中配置，关键参数如下：

All hyperparameters are configured in `trainer/distill_config.yaml`. Key parameters are as follows:

### 蒸馏损失权重 / Distillation Loss Weights

```yaml
distillation:
  temperature:
    initial: 2.0      # 初始温度
    final: 1.0         # 最终温度
    warmup_steps: 1000  # 退火步数
  loss_weights:
    kl: 1.0            # KL 散度权重
    feature: 0.5       # 特征对齐权重
    task: 0.3          # 任务损失权重
```

### 分阶段训练 / Phased Training

| 阶段 / Stage | 训练目标 / Training Target | Batch Size | 梯度累积 / Gradient Accumulation | 学习率 / Learning Rate | 预估显存 / Est. VRAM |
|------|---------|-----------|---------|--------|---------|
| 1 | 文本编码器 | 8 | ×4 | 1e-4 | ~8GB |
| 2 | 融合模块 | 4 | ×8 | 5e-5 | ~10GB |
| 3 | 端到端 | 2 | ×16 | 2e-5 | ~14GB |

### 显存优化 / Memory Optimization

- 混合精度训练（bf16）
- 梯度检查点
- 梯度累积（有效 batch = 32）
- OOM 自动降级（清空缓存 + 跳过批次）
- 视觉编码器冻结

- Mixed precision training (bf16)
- Gradient checkpointing
- Gradient accumulation (effective batch = 32)
- Automatic OOM degradation (clear cache + skip batch)
- Frozen vision encoder

---

## 教师模型信息 / Teacher Model Information

| 模型 / Model | 魔搭 ID / ModelScope ID | 参数量 / Parameters | 链接 / Link | 状态 / Status |
|------|---------|--------|------|------|
| DeepSeek-V4-Pro-Base | `deepseek-ai/DeepSeek-V4-Pro-Base` | 1.6T (49B 激活) | [魔搭链接](https://www.modelscope.cn/models/deepseek-ai/DeepSeek-V4-Pro-Base) | ✓ 已验证 |
| DINOv3 ViT-S/16 | `facebook/dinov3-vits16-pretrain-lvd1689m` | 21M | [魔搭链接](https://www.modelscope.cn/models/facebook/dinov3-vits16-pretrain-lvd1689m) | ✓ 已验证 |

---

## 模型保存格式 / Model Save Formats

训练完成后，模型权重以三种格式保存：

After training, model weights are saved in three formats:

| 格式 / Format | 文件 / File | 说明 / Description |
|------|------|------|
| PyTorch | `model_name.bin` | 标准 PyTorch 格式 |
| SafeTensors | `model_name.safetensors` | HuggingFace 安全格式（需安装 safetensors） |
| Checkpoint | `model_name_checkpoint.pt` | 含优化器状态 + 对齐模块权重 |

---

## 已知限制与待验证项 / Known Limitations and Pending Items

| # | 项目 / Item | 状态 / Status | 说明 / Description |
|---|------|------|------|
| 1 | 真实数据集加载 | 待实现 | 当前使用 DummyDistillDataset，需替换为 MultimodalDistillDataset + JSONL 数据 |
| 2 | DINOv3 License | 待验证 | 需确认是否允许商业蒸馏 |
| 3 | DeepSeek tokenizer vocab_size | 待验证 | 配置中设为 100000，实际需加载 tokenizer 确认 |
| 4 | HHAM 线性注意力特征映射 | 待验证 | 使用 φ(x)=elu(x)+1，论文未明确指定 |
| 5 | HHAM DRG 门控网络结构 | 待验证 | 论文未完全明确具体结构 |

代码中所有不确定项均已标注 `【AI不确定，需人工验证】`。

All uncertain items in the code are marked with `【AI不确定，需人工验证】`.

---

## 论文引用 / Paper References

### UAF

```
Unnormalized Attention Flow (UAF)
- Section 3.1: Attention Dilution Theorem
- Section 4.1: Principle of De-Normalization
- Section 4.2: Mechanism of Continuous State Evolution
- Section 4.3: Design of Local-Sensitive Readout
```

### HHAM-DRG

```
HHAM-DRG: Hierarchical Hybrid Attentive Memory with Dynamic Residual Gating
- Section 3.2: Tri-Level Attention Mechanism
- Section 3.3: Pyramid-Style KV Cache Compression
- Section 3.4: Dynamic Residual Gating
```

### DINOv3

```
@misc{simeoni2025dinov3,
  title={{DINOv3}},
  author={Sim\'eoni, Oriane and Vo, Huy V. and others},
  year={2025},
  eprint={2508.10104},
  archivePrefix={arXiv}
}
```

---

## 许可证 / License

本项目仅供学术研究使用。

This project is for academic research purposes only.

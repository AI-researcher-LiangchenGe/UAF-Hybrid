# 实验报告模板: UAF 多模态蒸馏

> **注意**: 此模板由 `analyze_results.py` 中的 `auto_generate_report()` 函数自动填充。
> 手动编辑时，请保留占位符格式 `{{variable_name}}`。

---

## 1. 实验背景

### 1.1 目标

将 DeepSeek-V4-Pro（文本教师）和 DINOv3（视觉教师）蒸馏到 UAF（Unnormalized Attention Flow）学生模型中，构建多模态大模型。

### 1.2 教师模型

| 模型 | 魔搭ID | 参数量 | 作用 |
|------|--------|--------|------|
| DeepSeek-V4-Pro-Base | `deepseek-ai/DeepSeek-V4-Pro-Base` | 1.6T (49B激活) | 文本生成教师 |
| DINOv3 ViT-S/16 | `facebook/dinov3-vits16-pretrain-lvd1689m` | 21M | 视觉特征提取教师 |

### 1.3 学生模型架构

```
┌─────────────────────────────────────────────────────────┐
│                  多模态学生模型                          │
├─────────────────────────────────────────────────────────┤
│  ┌──────────────┐      ┌──────────────────────┐        │
│  │  视觉编码器   │      │     文本编码器        │        │
│  │  DINOv3      │      │  UAF_StateIntegrator │        │
│  │  (冻结)      │      │  (6层, d_model=512)  │        │
│  └──────┬───────┘      └──────────┬───────────┘        │
│         │                         │                     │
│         └──────────┬──────────────┘                     │
│                    ▼                                     │
│           ┌─────────────────┐                           │
│           │  交叉注意力融合  │                           │
│           └────────┬────────┘                           │
│                    ▼                                     │
│           ┌─────────────────┐                           │
│           │    LM Head      │                           │
│           │  (文本生成)      │                           │
│           └─────────────────┘                           │
└─────────────────────────────────────────────────────────┘
```

---

## 2. 实验设置

### 2.1 超参数

| 参数 | 阶段1 | 阶段2 | 阶段3 |
|------|-------|-------|-------|
| 训练目标 | 文本编码器 | 融合模块 | 端到端 |
| Epochs | {{stage1_epochs}} | {{stage2_epochs}} | {{stage3_epochs}} |
| 学习率 | {{stage1_lr}} | {{stage2_lr}} | {{stage3_lr}} |
| Batch Size | {{stage1_batch}} | {{stage2_batch}} | {{stage3_batch}} |
| 梯度累积 | {{stage1_accum}} | {{stage2_accum}} | {{stage3_accum}} |

### 2.2 蒸馏配置

| 参数 | 值 |
|------|-----|
| 初始温度 | {{initial_temperature}} |
| 最终温度 | {{final_temperature}} |
| KL Loss 权重 | {{kl_weight}} |
| Feature Loss 权重 | {{feature_weight}} |
| Task Loss 权重 | {{task_weight}} |

### 2.3 硬件环境

| 项目 | 配置 |
|------|------|
| GPU | {{gpu_model}} |
| 显存 | {{gpu_memory}} |
| 训练时间 | {{training_time}} |

---

## 3. 实验结果

### 3.1 关键指标

| 指标 | 值 |
|------|-----|
| 最佳验证准确率 | {{best_val_acc}} |
| 最佳验证准确率步数 | {{best_val_acc_step}} |
| 最佳验证损失 | {{best_val_loss}} |
| 最佳验证损失步数 | {{best_val_loss_step}} |
| 最终训练损失 | {{final_train_loss}} |
| 最终验证损失 | {{final_val_loss}} |
| 最终验证准确率 | {{final_val_acc}} |
| 总训练步数 | {{total_steps}} |

### 3.2 训练曲线

![Training Curves](training_curves.png)

### 3.3 损失下降曲线

```
Train Loss: {{train_loss_trend}}
Val Loss:   {{val_loss_trend}}
Val Acc:    {{val_acc_trend}}
```

---

## 4. 关键发现

### 4.1 收敛性分析

{{convergence_analysis}}

### 4.2 蒸馏效果

{{distillation_effectiveness}}

### 4.3 多模态融合效果

{{multimodal_fusion_analysis}}

### 4.4 与教师模型对比

| 模型 | 参数量 | 验证准确率 | 推理速度 |
|------|--------|------------|----------|
| DeepSeek-V4-Pro (教师) | 1.6T | {{teacher_acc}} | {{teacher_speed}} |
| UAF Student (学生) | {{student_params}} | {{student_acc}} | {{student_speed}} |
| 压缩比 | {{compression_ratio}}x | - | {{speedup_ratio}}x |

---

## 5. 结论与建议

### 5.1 主要结论

1. {{conclusion_1}}
2. {{conclusion_2}}
3. {{conclusion_3}}

### 5.2 改进建议

1. {{suggestion_1}}
2. {{suggestion_2}}
3. {{suggestion_3}}

### 5.3 后续工作

- [ ] {{follow_up_1}}
- [ ] {{follow_up_2}}
- [ ] {{follow_up_3}}

---

## 附录

### A. 模型权重文件

训练完成后，模型权重保存为以下三种格式：

| 格式 | 文件名 | 说明 |
|------|--------|------|
| PyTorch | `{{model_name}}.bin` | 标准 PyTorch 格式 |
| SafeTensors | `{{model_name}}.safetensors` | HuggingFace 安全格式 |
| Checkpoint | `{{model_name}}_checkpoint.pt` | 包含优化器状态的完整检查点 |

### B. 复现命令

```bash
# 运行训练
bash run_distill.sh

# 分析结果
python trainer/analyze_results.py \
    --log logs/training_log.csv \
    --output-dir outputs/analysis
```

### C. 引用

```bibtex
@misc{uaf_multimodal_distillation_2026,
  title={Distilling DeepSeek-V4-Pro and DINOv3 into UAF Architecture},
  author={UAF Project Team},
  year={2026},
  howpublished={\url{https://github.com/your-repo/uaf_project}}
}
```

---

*报告生成时间: {{generation_time}}*
*报告生成工具: analyze_results.py*

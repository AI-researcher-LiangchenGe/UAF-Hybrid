"""
训练结果分析脚本 / Training Results Analysis Script

功能 / Features:
    1. 读取训练日志（CSV格式：step,train_loss,val_loss,val_acc）
       / Read training log (CSV format: step,train_loss,val_loss,val_acc)
    2. 绘制训练/验证损失曲线 / Plot training/validation loss curves
    3. 计算并打印最佳验证准确率、达到最佳准确率的步数
       / Compute and print best validation accuracy, step at which it was achieved
    4. 自动生成实验报告 / Auto-generate experiment report

Author: AI Assistant
Date: 2026-05-26
"""

import os
import sys
import csv
import argparse
from pathlib import Path
from typing import Dict, List, Optional, Tuple
from dataclasses import dataclass

import numpy as np

# 尝试导入 matplotlib，如果失败则给出友好提示
# Try importing matplotlib, give friendly message if it fails
try:
    import matplotlib.pyplot as plt
    import matplotlib
    matplotlib.use('Agg')  # 使用非交互式后端 / Use non-interactive backend
    MATPLOTLIB_AVAILABLE = True
except ImportError:
    MATPLOTLIB_AVAILABLE = False
    print("警告: matplotlib 未安装，绘图功能不可用 / Warning: matplotlib not installed, plotting unavailable")
    print("请运行: pip install matplotlib")


@dataclass
class TrainingMetrics:
    """训练指标数据类。 / Training metrics dataclass."""
    steps: List[int]
    train_losses: List[float]
    val_losses: List[float]
    val_accs: List[float]

    def __post_init__(self):
        """验证数据一致性。 / Validate data consistency."""
        assert len(self.steps) == len(self.train_losses), "steps 和 train_losses 长度不一致 / steps and train_losses length mismatch"
        assert len(self.steps) == len(self.val_losses), "steps 和 val_losses 长度不一致 / steps and val_losses length mismatch"
        assert len(self.steps) == len(self.val_accs), "steps 和 val_accs 长度不一致 / steps and val_accs length mismatch"


def read_training_log(log_path: str) -> TrainingMetrics:
    """
    读取训练日志 CSV 文件。 / Read training log CSV file.

    期望格式 / Expected format:
        step,train_loss,val_loss,val_acc
        0,4.523,4.512,0.123
        100,3.234,3.198,0.234
        ...

    Args:
        log_path: 日志文件路径 / Log file path

    Returns:
        TrainingMetrics 对象 / TrainingMetrics object

    Raises:
        FileNotFoundError: 日志文件不存在 / Log file does not exist
        ValueError: 日志格式错误 / Log format error
    """
    if not os.path.exists(log_path):
        raise FileNotFoundError(
            f"日志文件不存在: {log_path}\n"
            f"请确保训练脚本已正确生成日志文件。\n"
            f"期望格式: step,train_loss,val_loss,val_acc\n"
            f"Log file does not exist: {log_path}\n"
            f"Please ensure the training script has correctly generated the log file.\n"
            f"Expected format: step,train_loss,val_loss,val_acc"
        )

    steps = []
    train_losses = []
    val_losses = []
    val_accs = []

    with open(log_path, 'r', encoding='utf-8') as f:
        reader = csv.DictReader(f)

        # 检查表头 / Check headers
        expected_headers = {'step', 'train_loss', 'val_loss', 'val_acc'}
        headers = set(reader.fieldnames or [])

        if not expected_headers.issubset(headers):
            missing = expected_headers - headers
            raise ValueError(
                f"日志文件格式错误，缺少列: {missing}\n"
                f"期望的列: {expected_headers}\n"
                f"实际的列: {headers}\n"
                f"Log file format error, missing columns: {missing}\n"
                f"Expected columns: {expected_headers}\n"
                f"Actual columns: {headers}"
            )

        for row in reader:
            try:
                steps.append(int(row['step']))
                train_losses.append(float(row['train_loss']))
                val_losses.append(float(row['val_loss']))
                val_accs.append(float(row['val_acc']))
            except (ValueError, KeyError) as e:
                raise ValueError(f"解析行时出错: {row}, 错误: {e} / Error parsing row: {row}, error: {e}")

    if len(steps) == 0:
        raise ValueError("日志文件为空或没有有效数据 / Log file is empty or has no valid data")

    return TrainingMetrics(steps, train_losses, val_losses, val_accs)


def compute_statistics(metrics: TrainingMetrics) -> Dict:
    """
    计算训练统计信息。 / Compute training statistics.

    Args:
        metrics: 训练指标 / Training metrics

    Returns:
        统计信息字典 / Statistics dictionary
    """
    # 找到最佳验证准确率 / Find best validation accuracy
    best_val_acc_idx = np.argmax(metrics.val_accs)
    best_val_acc = metrics.val_accs[best_val_acc_idx]
    best_val_acc_step = metrics.steps[best_val_acc_idx]

    # 找到最佳验证损失 / Find best validation loss
    best_val_loss_idx = np.argmin(metrics.val_losses)
    best_val_loss = metrics.val_losses[best_val_loss_idx]
    best_val_loss_step = metrics.steps[best_val_loss_idx]

    # 最终指标 / Final metrics
    final_train_loss = metrics.train_losses[-1]
    final_val_loss = metrics.val_losses[-1]
    final_val_acc = metrics.val_accs[-1]

    # 计算收敛速度（损失下降到最终值10%范围内的步数）
    # Compute convergence speed (steps for loss to fall within 10% of final value)
    threshold = final_train_loss * 1.1
    convergence_steps = None
    for i, loss in enumerate(metrics.train_losses):
        if loss <= threshold:
            convergence_steps = metrics.steps[i]
            break

    stats = {
        'best_val_acc': best_val_acc,
        'best_val_acc_step': best_val_acc_step,
        'best_val_loss': best_val_loss,
        'best_val_loss_step': best_val_loss_step,
        'final_train_loss': final_train_loss,
        'final_val_loss': final_val_loss,
        'final_val_acc': final_val_acc,
        'convergence_steps': convergence_steps,
        'total_steps': metrics.steps[-1],
        'avg_train_loss': np.mean(metrics.train_losses),
        'avg_val_loss': np.mean(metrics.val_losses),
        'avg_val_acc': np.mean(metrics.val_accs),
    }

    return stats


def plot_training_curves(
    metrics: TrainingMetrics,
    output_path: str,
    title: str = "Training Progress"
) -> bool:
    """
    绘制训练曲线。 / Plot training curves.

    Args:
        metrics: 训练指标 / Training metrics
        output_path: 输出图片路径 / Output image path
        title: 图表标题 / Chart title

    Returns:
        是否成功 / Whether successful
    """
    if not MATPLOTLIB_AVAILABLE:
        print("错误: matplotlib 未安装，无法绘图 / Error: matplotlib not installed, cannot plot")
        return False

    # 设置样式 / Set style
    plt.style.use('seaborn-v0_8-whitegrid')

    fig, axes = plt.subplots(2, 1, figsize=(12, 10))
    fig.suptitle(title, fontsize=16, fontweight='bold')

    # 损失曲线 / Loss curve
    ax1 = axes[0]
    ax1.plot(metrics.steps, metrics.train_losses, 'b-', label='Train Loss', linewidth=2)
    ax1.plot(metrics.steps, metrics.val_losses, 'r-', label='Val Loss', linewidth=2)
    ax1.set_xlabel('Step', fontsize=12)
    ax1.set_ylabel('Loss', fontsize=12)
    ax1.set_title('Training and Validation Loss', fontsize=14)
    ax1.legend(fontsize=10)
    ax1.grid(True, alpha=0.3)

    # 准确率曲线 / Accuracy curve
    ax2 = axes[1]
    ax2.plot(metrics.steps, metrics.val_accs, 'g-', label='Val Accuracy', linewidth=2)
    ax2.set_xlabel('Step', fontsize=12)
    ax2.set_ylabel('Accuracy', fontsize=12)
    ax2.set_title('Validation Accuracy', fontsize=14)
    ax2.legend(fontsize=10)
    ax2.grid(True, alpha=0.3)

    # 标记最佳点 / Mark best point
    best_val_acc_idx = np.argmax(metrics.val_accs)
    best_step = metrics.steps[best_val_acc_idx]
    best_acc = metrics.val_accs[best_val_acc_idx]
    ax2.plot(best_step, best_acc, 'r*', markersize=15, label=f'Best: {best_acc:.4f}')
    ax2.legend(fontsize=10)

    plt.tight_layout()
    plt.savefig(output_path, dpi=150, bbox_inches='tight')
    plt.close()

    print(f"训练曲线已保存 / Training curves saved: {output_path}")
    return True


def print_statistics(stats: Dict):
    """
    打印统计信息。 / Print statistics.

    Args:
        stats: 统计信息字典 / Statistics dictionary
    """
    print("\n" + "="*60)
    print("训练统计信息 / Training Statistics")
    print("="*60)
    print(f"总训练步数 / Total training steps: {stats['total_steps']}")
    print(f"\n最佳验证准确率 / Best validation accuracy: {stats['best_val_acc']:.4f} (步数 / step: {stats['best_val_acc_step']})")
    print(f"最佳验证损失 / Best validation loss: {stats['best_val_loss']:.4f} (步数 / step: {stats['best_val_loss_step']})")
    print(f"\n最终训练损失 / Final training loss: {stats['final_train_loss']:.4f}")
    print(f"最终验证损失 / Final validation loss: {stats['final_val_loss']:.4f}")
    print(f"最终验证准确率 / Final validation accuracy: {stats['final_val_acc']:.4f}")
    print(f"\n平均训练损失 / Average training loss: {stats['avg_train_loss']:.4f}")
    print(f"平均验证损失 / Average validation loss: {stats['avg_val_loss']:.4f}")
    print(f"平均验证准确率 / Average validation accuracy: {stats['avg_val_acc']:.4f}")
    if stats['convergence_steps']:
        print(f"\n收敛步数 / Convergence steps: {stats['convergence_steps']}")
    print("="*60)


def auto_generate_report(
    log_path: str,
    output_dir: str,
    experiment_name: str = "UAF Multimodal Distillation",
    config: Optional[Dict] = None
) -> str:
    """
    自动生成实验报告。 / Auto-generate experiment report.

    Args:
        log_path: 训练日志路径 / Training log path
        output_dir: 输出目录 / Output directory
        experiment_name: 实验名称 / Experiment name
        config: 实验配置（可选） / Experiment configuration (optional)

    Returns:
        生成的报告路径 / Generated report path
    """
    # 读取日志 / Read log
    metrics = read_training_log(log_path)
    stats = compute_statistics(metrics)

    # 创建输出目录 / Create output directory
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    # 绘制曲线 / Plot curves
    plot_path = output_dir / "training_curves.png"
    plot_training_curves(metrics, str(plot_path), title=experiment_name)

    # 生成报告 / Generate report
    report_path = output_dir / "experiment_report.md"

    report_content = f"""# 实验报告: {experiment_name}

生成时间 / Generated at: {__import__('datetime').datetime.now().strftime('%Y-%m-%d %H:%M:%S')}

## 1. 实验背景 / 1. Experiment Background

本实验将 DeepSeek-V4-Pro（文本教师）和 DINOv3（视觉教师）蒸馏到 UAF（Unnormalized Attention Flow）学生模型中，构建多模态大模型。
/ This experiment distills DeepSeek-V4-Pro (text teacher) and DINOv3 (vision teacher) into a UAF (Unnormalized Attention Flow) student model to build a multimodal large model.

### 1.1 教师模型 / Teacher Models

| 模型 / Model | 来源 / Source | 参数量 / Params | 作用 / Role |
|------|------|--------|------|
| DeepSeek-V4-Pro-Base | 魔搭社区 / ModelScope | 1.6T (49B激活 / active) | 文本生成教师 / Text generation teacher |
| DINOv3 ViT-S/16 | 魔搭社区 / ModelScope | 21M | 视觉特征提取教师 / Vision feature extraction teacher |

### 1.2 学生模型架构 / Student Model Architecture

- **文本编码器 / Text encoder**: UAF_StateIntegrator (6层 / layers, d_model=512)
- **视觉编码器 / Vision encoder**: DINOv3 ViT-S/16 + 投影层 (冻结 / frozen)
- **融合模块 / Fusion module**: 交叉注意力 / Cross-attention
- **输出头 / Output head**: LM Head (词汇表大小 / vocab size: 100k)

## 2. 实验设置 / 2. Experiment Setup

"""

    # 添加配置信息 / Add configuration info
    if config:
        report_content += "### 2.1 超参数 / Hyperparameters\n\n"
        report_content += "| 参数 / Parameter | 值 / Value |\n"
        report_content += "|------|-----|\n"

        if 'training' in config and 'stages' in config['training']:
            for stage in config['training']['stages']:
                report_content += f"| {stage['name']} - Epochs | {stage['epochs']} |\n"
                report_content += f"| {stage['name']} - Learning Rate | {stage['learning_rate']} |\n"
                report_content += f"| {stage['name']} - Batch Size | {stage['batch_size']} |\n"

        if 'distillation' in config:
            report_content += f"| Temperature | {config['distillation'].get('temperature', {}).get('initial', 'N/A')} |\n"
            weights = config['distillation'].get('loss_weights', {})
            report_content += f"| KL Loss Weight | {weights.get('kl', 'N/A')} |\n"
            report_content += f"| Feature Loss Weight | {weights.get('feature', 'N/A')} |\n"
            report_content += f"| Task Loss Weight | {weights.get('task', 'N/A')} |\n"

        report_content += "\n"

    report_content += f"""## 3. 实验结果 / 3. Experiment Results

### 3.1 关键指标 / Key Metrics

| 指标 / Metric | 值 / Value |
|------|-----|
| 最佳验证准确率 / Best val accuracy | {stats['best_val_acc']:.4f} |
| 最佳验证准确率步数 / Best val accuracy step | {stats['best_val_acc_step']} |
| 最佳验证损失 / Best val loss | {stats['best_val_loss']:.4f} |
| 最佳验证损失步数 / Best val loss step | {stats['best_val_loss_step']} |
| 最终训练损失 / Final train loss | {stats['final_train_loss']:.4f} |
| 最终验证损失 / Final val loss | {stats['final_val_loss']:.4f} |
| 最终验证准确率 / Final val accuracy | {stats['final_val_acc']:.4f} |
| 总训练步数 / Total training steps | {stats['total_steps']} |

### 3.2 训练曲线 / Training Curves

![Training Curves](training_curves.png)

## 4. 关键发现 / 4. Key Findings

<!-- 根据实验结果填写 / Fill in based on experiment results -->

### 4.1 收敛性分析 / Convergence Analysis

- 模型在约 {stats['convergence_steps'] if stats['convergence_steps'] else 'N/A'} 步时基本收敛
  / Model basically converges at approximately {stats['convergence_steps'] if stats['convergence_steps'] else 'N/A'} steps
- 验证准确率最高达到 {stats['best_val_acc']:.4f}
  / Validation accuracy reaches up to {stats['best_val_acc']:.4f}

### 4.2 蒸馏效果 / Distillation Effect

<!-- 对比教师模型和学生模型的性能差距 -->
<!-- Compare performance gap between teacher and student models -->

### 4.3 多模态融合效果 / Multimodal Fusion Effect

<!-- 分析视觉特征对文本生成的影响 -->
<!-- Analyze the impact of visual features on text generation -->

## 5. 结论与建议 / 5. Conclusions and Recommendations

<!-- 总结实验结论，提出改进建议 -->
<!-- Summarize experiment conclusions, propose improvement suggestions -->

### 5.1 主要结论 / Main Conclusions

1.
2.
3.

### 5.2 改进建议 / Improvement Suggestions

1.
2.
3.

---

*报告由 analyze_results.py 自动生成 / Report auto-generated by analyze_results.py*
"""

    with open(report_path, 'w', encoding='utf-8') as f:
        f.write(report_content)

    print(f"实验报告已生成 / Experiment report generated: {report_path}")
    return str(report_path)


def main():
    """主函数。 / Main function."""
    parser = argparse.ArgumentParser(description='分析训练结果 / Analyze training results')
    parser.add_argument('--log', type=str, default='logs/training_log.csv',
                        help='训练日志 CSV 文件路径 / Training log CSV file path')
    parser.add_argument('--output-dir', type=str, default='outputs/analysis',
                        help='输出目录 / Output directory')
    parser.add_argument('--name', type=str, default='UAF Multimodal Distillation',
                        help='实验名称 / Experiment name')
    parser.add_argument('--config', type=str, default=None,
                        help='配置文件路径（用于生成详细报告） / Config file path (for detailed report)')
    args = parser.parse_args()

    print(f"分析训练日志 / Analyzing training log: {args.log}")

    try:
        # 读取日志 / Read log
        metrics = read_training_log(args.log)
        print(f"成功读取 {len(metrics.steps)} 条记录 / Successfully read {len(metrics.steps)} records")

        # 计算统计信息 / Compute statistics
        stats = compute_statistics(metrics)
        print_statistics(stats)

        # 绘制曲线 / Plot curves
        if MATPLOTLIB_AVAILABLE:
            output_dir = Path(args.output_dir)
            output_dir.mkdir(parents=True, exist_ok=True)
            plot_path = output_dir / "training_curves.png"
            plot_training_curves(metrics, str(plot_path), title=args.name)

        # 生成报告 / Generate report
        config = None
        if args.config:
            import yaml
            with open(args.config, 'r', encoding='utf-8') as f:
                config = yaml.safe_load(f)

        report_path = auto_generate_report(
            args.log,
            args.output_dir,
            experiment_name=args.name,
            config=config
        )

        print(f"\n分析完成! / Analysis complete!")
        print(f"输出目录 / Output directory: {args.output_dir}")

    except FileNotFoundError as e:
        print(f"\n错误: {e}")
        print("\n请确保 / Please ensure:")
        print("1. 训练脚本已正确运行并生成日志文件 / Training script has run correctly and generated log file")
        print("2. 日志文件路径正确 / Log file path is correct")
        print("3. 日志格式为 CSV: step,train_loss,val_loss,val_acc / Log format is CSV: step,train_loss,val_loss,val_acc")
        sys.exit(1)

    except Exception as e:
        print(f"\n错误: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)


if __name__ == "__main__":
    main()

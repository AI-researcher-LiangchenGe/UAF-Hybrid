"""
UAF 模型训练脚本 / UAF Model Training Script

提供基础的训练循环，用于训练基于 UAF 的模型。
/ Provides a basic training loop for training UAF-based models.
"""

import torch
import torch.nn as nn
from torch.utils.data import DataLoader, Dataset
import os
import sys
from typing import Optional, Dict, Any

# 添加父目录到路径 / Add parent directory to path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from model.uaf_attention import UAF_StateIntegrator
from model.hham_block import HHAMBlock


class SimpleSequenceModel(nn.Module):
    """
    简单的序列模型，使用 UAF 或 HHAM 作为核心组件。
    / Simple sequence model using UAF or HHAM as the core component.

    Args:
        vocab_size: 词汇表大小 / Vocabulary size
        d_model: 模型维度 / Model dimension
        n_layers: 层数 / Number of layers
        block_type: 使用的块类型 ('uaf' 或 'hham') / Block type to use ('uaf' or 'hham')
    """

    def __init__(
        self,
        vocab_size: int,
        d_model: int = 512,
        n_layers: int = 6,
        block_type: str = 'uaf'
    ):
        super().__init__()
        self.d_model = d_model
        self.block_type = block_type

        # Token embedding / Token 嵌入
        self.embedding = nn.Embedding(vocab_size, d_model)

        # Position encoding (simplified) / 位置编码（简化版）
        self.pos_encoding = nn.Parameter(torch.randn(1, 10000, d_model) * 0.02)

        # Build layers / 构建层
        if block_type == 'uaf':
            self.layers = nn.ModuleList([
                UAF_StateIntegrator(d_model=d_model, eta=1.0)
                for _ in range(n_layers)
            ])
        elif block_type == 'hham':
            self.layers = nn.ModuleList([
                HHAMBlock(
                    d_model=d_model,
                    n_heads=8,
                    layer_idx=i,
                    n_layers=n_layers
                )
                for i in range(n_layers)
            ])
        else:
            raise ValueError(f"Unknown block_type: {block_type}")

        # Output projection / 输出投影
        self.output_proj = nn.Linear(d_model, vocab_size)

        self._init_weights()

    def _init_weights(self):
        """初始化权重。 / Initialize weights."""
        for p in self.parameters():
            if p.dim() > 1:
                nn.init.xavier_uniform_(p)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """
        前向传播。 / Forward pass.

        Args:
            x: 输入 token IDs，shape (batch, seq_len) / Input token IDs, shape (batch, seq_len)

        Returns:
            输出 logits，shape (batch, seq_len, vocab_size)
            / Output logits, shape (batch, seq_len, vocab_size)
        """
        batch_size, seq_len = x.shape

        # Embedding + positional encoding / 嵌入 + 位置编码
        x = self.embedding(x)  # (batch, seq_len, d_model)
        x = x + self.pos_encoding[:, :seq_len, :]

        # Pass through layers / 通过各层
        for layer in self.layers:
            x = layer(x)

        # Output projection / 输出投影
        logits = self.output_proj(x)  # (batch, seq_len, vocab_size)

        return logits

    def generate(
        self,
        input_ids: torch.Tensor,
        max_new_tokens: int = 100,
        temperature: float = 1.0,
        top_k: Optional[int] = None
    ) -> torch.Tensor:
        """
        自回归生成。 / Autoregressive generation.

        Args:
            input_ids: 输入 token IDs，shape (batch, seq_len)
                      / Input token IDs, shape (batch, seq_len)
            max_new_tokens: 要生成的新 token 数量 / Number of new tokens to generate
            temperature: 采样温度 / Sampling temperature
            top_k: Top-k 采样参数 / Top-k sampling parameter

        Returns:
            生成的 token IDs，shape (batch, seq_len + max_new_tokens)
            / Generated token IDs, shape (batch, seq_len + max_new_tokens)
        """
        self.eval()

        with torch.no_grad():
            for _ in range(max_new_tokens):
                # 获取预测 / Get predictions
                logits = self.forward(input_ids)
                logits = logits[:, -1, :] / temperature  # 只取最后一个位置 / Take last position only

                # Top-k 采样 / Top-k sampling
                if top_k is not None:
                    v, _ = torch.topk(logits, min(top_k, logits.size(-1)))
                    logits[logits < v[:, [-1]]] = float('-inf')

                # 采样 / Sampling
                probs = torch.softmax(logits, dim=-1)
                next_token = torch.multinomial(probs, num_samples=1)

                # 追加到序列 / Append to sequence
                input_ids = torch.cat([input_ids, next_token], dim=1)

        return input_ids


class DummySequenceDataset(Dataset):
    """用于测试的虚拟序列数据集。 / Virtual sequence dataset for testing."""

    def __init__(self, vocab_size: int, seq_len: int, num_samples: int = 1000):
        self.vocab_size = vocab_size
        self.seq_len = seq_len
        self.num_samples = num_samples

        # 生成随机数据 / Generate random data
        torch.manual_seed(42)
        self.data = torch.randint(0, vocab_size, (num_samples, seq_len))

    def __len__(self):
        return self.num_samples

    def __getitem__(self, idx):
        # 输入是前 seq_len-1 个 token，目标是后 seq_len-1 个 token
        # Input is first seq_len-1 tokens, target is last seq_len-1 tokens
        x = self.data[idx, :-1]
        y = self.data[idx, 1:]
        return x, y


def train_epoch(
    model: nn.Module,
    dataloader: DataLoader,
    optimizer: torch.optim.Optimizer,
    device: torch.device
) -> float:
    """
    训练一个 epoch。 / Train one epoch.

    Args:
        model: 模型 / Model
        dataloader: 数据加载器 / Data loader
        optimizer: 优化器 / Optimizer
        device: 计算设备 / Compute device

    Returns:
        平均损失 / Average loss
    """
    model.train()
    total_loss = 0.0
    num_batches = 0

    criterion = nn.CrossEntropyLoss()

    for batch_idx, (x, y) in enumerate(dataloader):
        x, y = x.to(device), y.to(device)

        optimizer.zero_grad()

        # 前向传播 / Forward pass
        logits = model(x)

        # 计算损失 / Compute loss
        loss = criterion(logits.view(-1, logits.size(-1)), y.view(-1))

        # 反向传播 / Backward pass
        loss.backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
        optimizer.step()

        total_loss += loss.item()
        num_batches += 1

        if batch_idx % 100 == 0:
            print(f"  Batch {batch_idx}/{len(dataloader)}, Loss: {loss.item():.4f}")

    return total_loss / num_batches


def evaluate(
    model: nn.Module,
    dataloader: DataLoader,
    device: torch.device
) -> float:
    """
    评估模型。 / Evaluate model.

    Args:
        model: 模型 / Model
        dataloader: 数据加载器 / Data loader
        device: 计算设备 / Compute device

    Returns:
        平均损失 / Average loss
    """
    model.eval()
    total_loss = 0.0
    num_batches = 0

    criterion = nn.CrossEntropyLoss()

    with torch.no_grad():
        for x, y in dataloader:
            x, y = x.to(device), y.to(device)

            logits = model(x)
            loss = criterion(logits.view(-1, logits.size(-1)), y.view(-1))

            total_loss += loss.item()
            num_batches += 1

    return total_loss / num_batches


def main():
    """主训练函数。 / Main training function."""
    # 配置 / Configuration
    config = {
        'vocab_size': 10000,
        'd_model': 256,
        'n_layers': 4,
        'block_type': 'uaf',  # 'uaf' or 'hham'
        'seq_len': 128,
        'batch_size': 32,
        'num_epochs': 10,
        'lr': 1e-4,
    }

    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    print(f"Using device: {device}")
    print(f"Config: {config}")

    # 创建模型 / Create model
    model = SimpleSequenceModel(
        vocab_size=config['vocab_size'],
        d_model=config['d_model'],
        n_layers=config['n_layers'],
        block_type=config['block_type']
    ).to(device)

    print(f"Model parameters: {sum(p.numel() for p in model.parameters()):,}")

    # 创建数据集 / Create datasets
    train_dataset = DummySequenceDataset(
        vocab_size=config['vocab_size'],
        seq_len=config['seq_len'],
        num_samples=10000
    )
    val_dataset = DummySequenceDataset(
        vocab_size=config['vocab_size'],
        seq_len=config['seq_len'],
        num_samples=1000
    )

    train_loader = DataLoader(
        train_dataset,
        batch_size=config['batch_size'],
        shuffle=True,
        num_workers=0
    )
    val_loader = DataLoader(
        val_dataset,
        batch_size=config['batch_size'],
        shuffle=False,
        num_workers=0
    )

    # 优化器 / Optimizer
    optimizer = torch.optim.AdamW(model.parameters(), lr=config['lr'])

    # 训练循环 / Training loop
    print("\nStarting training...")
    for epoch in range(config['num_epochs']):
        print(f"\nEpoch {epoch + 1}/{config['num_epochs']}")

        train_loss = train_epoch(model, train_loader, optimizer, device)
        val_loss = evaluate(model, val_loader, device)

        print(f"Train Loss: {train_loss:.4f}, Val Loss: {val_loss:.4f}")

    print("\nTraining completed!")

    # 保存模型 / Save model
    save_path = "uaf_model.pt"
    torch.save(model.state_dict(), save_path)
    print(f"Model saved to {save_path}")


if __name__ == "__main__":
    main()

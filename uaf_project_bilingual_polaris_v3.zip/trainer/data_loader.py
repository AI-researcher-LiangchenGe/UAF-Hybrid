"""
多模态蒸馏数据加载器 / Multimodal Distillation Data Loader

本文件实现多模态蒸馏的数据加载相关组件，包括：
/ This file implements data loading components for multimodal distillation, including:
1. MultimodalDistillDataset — 加载图文对数据，提供教师和学生 tokenizer 处理后的输入
   / Load image-text pair data, providing inputs processed by both teacher and student tokenizers
2. DummyDistillDataset — 用于测试的虚拟数据集，不需要真实数据文件
   / Virtual dataset for testing, no real data files required
3. create_dataloader — 数据加载器工厂函数 / Data loader factory function
"""

import json
import os
import random
from typing import Dict, List, Optional

import torch
from torch.utils.data import DataLoader, Dataset
from torchvision import transforms

from model.alignment import TokenizerAligner


class MultimodalDistillDataset(Dataset):
    """加载图文对数据，同时提供教师和学生 tokenizer 处理后的输入。
    / Load image-text pair data, providing inputs processed by both teacher and student tokenizers.

    支持从 JSONL 格式的数据集文件中加载图文对数据，每行格式为：
    / Supports loading image-text pair data from JSONL format dataset files, each line format:
    {"image": "path/to/image.jpg", "text": "描述文本" / description text"}

    同时提供演示模式（is_demo=True），生成 100 条随机数据用于测试。
    / Also provides demo mode (is_demo=True), generating 100 random data items for testing.

    Args:
        data_path: 数据集文件路径（JSONL 格式） / Dataset file path (JSONL format)
        teacher_tokenizer: 教师模型的分词器（HuggingFace Tokenizer）
                          / Teacher model's tokenizer (HuggingFace Tokenizer)
        student_tokenizer: 学生模型的分词器（HuggingFace Tokenizer）
                          / Student model's tokenizer (HuggingFace Tokenizer)
        tokenizer_aligner: TokenizerAligner 实例，用于 token ID 映射
                          / TokenizerAligner instance for token ID mapping
        max_seq_length: 文本最大序列长度，默认为 512 / Max text sequence length, default 512
        image_size: 图像尺寸（正方形），默认为 224 / Image size (square), default 224
        is_demo: 是否使用演示模式（生成随机数据），默认为 False
                 / Whether to use demo mode (generate random data), default False

    Returns:
        字典，包含以下键 / Dictionary containing the following keys:
            - 'input_ids': 学生 tokenizer 编码的 token IDs (LongTensor, 已 pad)
              / Student tokenizer encoded token IDs (LongTensor, padded)
            - 'attention_mask': 注意力掩码 (LongTensor) / Attention mask (LongTensor)
            - 'labels': 标签，与 input_ids 相同但向左移一位，pad 位置设为 -100 (LongTensor)
              / Labels, same as input_ids but shifted left by one, pad positions set to -100 (LongTensor)
            - 'pixel_values': 图像张量 (FloatTensor, 归一化到 [-1, 1])
              / Image tensor (FloatTensor, normalized to [-1, 1])
            - 'teacher_input_ids': 教师 tokenizer 编码的 token IDs (LongTensor, 已 pad)
              / Teacher tokenizer encoded token IDs (LongTensor, padded)
            - 'teacher_attention_mask': 教师注意力掩码 (LongTensor)
              / Teacher attention mask (LongTensor)
    """

    def __init__(
        self,
        data_path: str,
        teacher_tokenizer,
        student_tokenizer,
        tokenizer_aligner: TokenizerAligner,
        max_seq_length: int = 512,
        image_size: int = 224,
        is_demo: bool = False,
    ):
        """初始化 MultimodalDistillDataset。 / Initialize MultimodalDistillDataset.

        Args:
            data_path: 数据集文件路径（JSONL 格式） / Dataset file path (JSONL format)
            teacher_tokenizer: 教师模型的分词器 / Teacher model's tokenizer
            student_tokenizer: 学生模型的分词器 / Student model's tokenizer
            tokenizer_aligner: TokenizerAligner 实例 / TokenizerAligner instance
            max_seq_length: 文本最大序列长度，默认为 512 / Max text sequence length, default 512
            image_size: 图像尺寸，默认为 224 / Image size, default 224
            is_demo: 是否使用演示模式，默认为 False / Whether to use demo mode, default False
        """
        self.data_path = data_path
        self.teacher_tokenizer = teacher_tokenizer
        self.student_tokenizer = student_tokenizer
        self.tokenizer_aligner = tokenizer_aligner
        self.max_seq_length = max_seq_length
        self.image_size = image_size
        self.is_demo = is_demo

        # 图像预处理流水线 / Image preprocessing pipeline
        self.transform = transforms.Compose([
            transforms.Resize((image_size, image_size)),
            transforms.ToTensor(),
            transforms.Normalize(
                mean=[0.485, 0.456, 0.406],
                std=[0.229, 0.224, 0.225],
            ),
        ])

        # 加载数据 / Load data
        if is_demo:
            self.data = self._create_demo_data()
        else:
            self.data = self._load_data(data_path)

    def _load_data(self, data_path: str) -> List[Dict]:
        """从 JSONL 文件加载数据。 / Load data from JSONL file.

        Args:
            data_path: JSONL 格式的数据集文件路径 / JSONL format dataset file path

        Returns:
            数据列表，每个元素为包含 'image' 和 'text' 键的字典
            / Data list, each element is a dict with 'image' and 'text' keys
        """
        data = []
        with open(data_path, 'r', encoding='utf-8') as f:
            for line in f:
                line = line.strip()
                if line:
                    data.append(json.loads(line))
        return data

    def __len__(self) -> int:
        """返回数据集大小。 / Return dataset size.

        Returns:
            数据集中样本的数量 / Number of samples in the dataset
        """
        return len(self.data)

    def __getitem__(self, idx: int) -> Dict[str, torch.Tensor]:
        """获取指定索引的样本。 / Get the sample at the specified index.

        对文本分别使用教师和学生 tokenizer 进行编码，对图像进行预处理和归一化。
        标签（labels）与 input_ids 相同但向左移一位，pad 位置设为 -100。
        / Encode text using teacher and student tokenizers separately, preprocess and normalize images.
        / Labels are the same as input_ids but shifted left by one, pad positions set to -100.

        Args:
            idx: 样本索引 / Sample index

        Returns:
            包含以下键的字典 / Dictionary containing the following keys:
                - 'input_ids': 学生 tokenizer 编码的 token IDs (LongTensor)
                  / Student tokenizer encoded token IDs (LongTensor)
                - 'attention_mask': 学生注意力掩码 (LongTensor) / Student attention mask (LongTensor)
                - 'labels': 标签，向左移一位，pad 位置为 -100 (LongTensor)
                  / Labels, shifted left by one, pad positions are -100 (LongTensor)
                - 'pixel_values': 图像张量 (FloatTensor) / Image tensor (FloatTensor)
                - 'teacher_input_ids': 教师 tokenizer 编码的 token IDs (LongTensor)
                  / Teacher tokenizer encoded token IDs (LongTensor)
                - 'teacher_attention_mask': 教师注意力掩码 (LongTensor)
                  / Teacher attention mask (LongTensor)
        """
        sample = self.data[idx]
        text = sample['text']
        image_path = sample['image']

        # 加载并预处理图像 / Load and preprocess image
        pixel_values = self._load_image(image_path)

        # 学生 tokenizer 编码 / Student tokenizer encoding
        student_encoded = self._tokenize(text, self.student_tokenizer, self.max_seq_length)
        input_ids = student_encoded['input_ids']       # (seq_len,)
        attention_mask = student_encoded['attention_mask']  # (seq_len,)

        # 创建 labels: 向左移一位，pad 位置设为 -100
        # Create labels: shift left by one, set pad positions to -100
        labels = input_ids.clone()
        labels[:-1] = input_ids[1:]
        labels[-1] = -100
        # 将 pad 位置（attention_mask 为 0 的位置）的 labels 设为 -100
        # Set labels at pad positions (where attention_mask is 0) to -100
        labels = labels.masked_fill(attention_mask == 0, -100)

        # 教师 tokenizer 编码 / Teacher tokenizer encoding
        teacher_encoded = self._tokenize(text, self.teacher_tokenizer, self.max_seq_length)
        teacher_input_ids = teacher_encoded['input_ids']
        teacher_attention_mask = teacher_encoded['attention_mask']

        return {
            'input_ids': input_ids,
            'attention_mask': attention_mask,
            'labels': labels,
            'pixel_values': pixel_values,
            'teacher_input_ids': teacher_input_ids,
            'teacher_attention_mask': teacher_attention_mask,
        }

    def _load_image(self, image_path: str) -> torch.Tensor:
        """加载并预处理图像。 / Load and preprocess image.

        使用 PIL 加载图像，然后通过 self.transform 进行 resize、转换为张量
        和归一化处理。归一化使用 ImageNet 的均值和标准差。
        / Use PIL to load image, then apply self.transform for resize, tensor conversion,
        / and normalization. Normalization uses ImageNet mean and std.

        Args:
            image_path: 图像文件路径 / Image file path

        Returns:
            预处理后的图像张量，shape 为 (3, image_size, image_size)，
            值域归一化到近似 [-1, 1]（基于 ImageNet 统计量）
            / Preprocessed image tensor, shape (3, image_size, image_size),
            / normalized to approximately [-1, 1] (based on ImageNet statistics)
        """
        from PIL import Image

        image = Image.open(image_path).convert('RGB')
        pixel_values = self.transform(image)
        return pixel_values

    def _tokenize(
        self,
        text: str,
        tokenizer,
        max_length: int,
    ) -> Dict[str, torch.Tensor]:
        """使用指定的 tokenizer 对文本进行编码。 / Encode text using the specified tokenizer.

        Args:
            text: 待编码的文本 / Text to encode
            tokenizer: HuggingFace Tokenizer 实例 / HuggingFace Tokenizer instance
            max_length: 最大序列长度 / Max sequence length

        Returns:
            包含 'input_ids' 和 'attention_mask' 的字典，值均为 LongTensor
            / Dictionary with 'input_ids' and 'attention_mask', both LongTensor
        """
        encoded = tokenizer(
            text,
            max_length=max_length,
            padding='max_length',
            truncation=True,
            return_tensors='pt',
        )
        # 去掉 batch 维度（squeeze 第 0 维） / Remove batch dimension (squeeze dim 0)
        input_ids = encoded['input_ids'].squeeze(0)       # (seq_len,)
        attention_mask = encoded['attention_mask'].squeeze(0)  # (seq_len,)
        return {
            'input_ids': input_ids,
            'attention_mask': attention_mask,
        }

    def _create_demo_data(self) -> List[Dict]:
        """创建演示数据（随机文本 + 随机图像路径）。 / Create demo data (random text + random image paths).

        生成 100 条随机数据用于测试，文本为随机字符串，图像路径为占位路径。
        / Generate 100 random data items for testing, text is random strings, image paths are placeholders.

        Returns:
            包含 100 条演示数据的列表，每条数据包含 'image' 和 'text' 键
            / List of 100 demo data items, each containing 'image' and 'text' keys
        """
        demo_data = []
        demo_texts = [
            "这是一张美丽的风景照片。",
            "图中有一只可爱的猫咪。",
            "城市夜景灯光璀璨。",
            "蓝天白云下的山脉。",
            "花园里盛开的鲜花。",
            "海滩上的日落美景。",
            "森林中的小木屋。",
            "雪地里的松树。",
            "河流穿过山谷。",
            "草原上奔跑的马匹。",
        ]
        for i in range(100):
            demo_data.append({
                'image': f"demo_image_{i:04d}.jpg",
                'text': demo_texts[i % len(demo_texts)],
            })
        return demo_data


class DummyDistillDataset(Dataset):
    """用于测试的虚拟数据集，不需要真实数据文件。
    / Virtual dataset for testing, no real data files required.

    生成随机数据，返回与 MultimodalDistillDataset 相同格式的字典。
    适用于快速测试和调试数据加载流程。
    / Generates random data, returns dicts in the same format as MultimodalDistillDataset.
    / Suitable for quick testing and debugging of the data loading pipeline.

    Args:
        num_samples: 样本数量，默认为 1000 / Number of samples, default 1000
        vocab_size: 词汇表大小（用于生成随机 token IDs），默认为 100000
                   / Vocabulary size (for generating random token IDs), default 100000
        seq_len: 序列长度，默认为 128 / Sequence length, default 128
        image_size: 图像尺寸（正方形），默认为 224 / Image size (square), default 224

    Returns:
        字典，包含以下键 / Dictionary containing the following keys:
            - 'input_ids': 随机 token IDs (LongTensor, shape: (seq_len,))
            - 'attention_mask': 随机注意力掩码 (LongTensor, shape: (seq_len,))
            - 'labels': 标签，向左移一位，pad 位置为 -100 (LongTensor, shape: (seq_len,))
            - 'pixel_values': 随机图像张量 (FloatTensor, shape: (3, image_size, image_size))
            - 'teacher_input_ids': 随机教师 token IDs (LongTensor, shape: (seq_len,))
            - 'teacher_attention_mask': 随机教师注意力掩码 (LongTensor, shape: (seq_len,))
    """

    def __init__(
        self,
        num_samples: int = 1000,
        vocab_size: int = 100000,
        seq_len: int = 128,
        image_size: int = 224,
    ):
        """初始化 DummyDistillDataset。 / Initialize DummyDistillDataset.

        Args:
            num_samples: 样本数量，默认为 1000 / Number of samples, default 1000
            vocab_size: 词汇表大小，默认为 100000 / Vocabulary size, default 100000
            seq_len: 序列长度，默认为 128 / Sequence length, default 128
            image_size: 图像尺寸，默认为 224 / Image size, default 224
        """
        self.num_samples = num_samples
        self.vocab_size = vocab_size
        self.seq_len = seq_len
        self.image_size = image_size

    def __len__(self) -> int:
        """返回数据集大小。 / Return dataset size.

        Returns:
            样本数量 / Number of samples
        """
        return self.num_samples

    def __getitem__(self, idx: int) -> Dict[str, torch.Tensor]:
        """获取指定索引的虚拟样本。 / Get virtual sample at the specified index.

        生成与 MultimodalDistillDataset 格式完全一致的随机数据字典。
        / Generate a random data dict in the exact same format as MultimodalDistillDataset.

        Args:
            idx: 样本索引（未使用，每次返回随机数据）
                 / Sample index (unused, returns random data each time)

        Returns:
            包含以下键的字典 / Dictionary containing the following keys:
                - 'input_ids': 随机 token IDs (LongTensor) / Random token IDs (LongTensor)
                - 'attention_mask': 注意力掩码 (LongTensor) / Attention mask (LongTensor)
                - 'labels': 标签，向左移一位，pad 位置为 -100 (LongTensor)
                  / Labels, shifted left by one, pad positions are -100 (LongTensor)
                - 'pixel_values': 随机图像张量 (FloatTensor) / Random image tensor (FloatTensor)
                - 'teacher_input_ids': 随机教师 token IDs (LongTensor)
                  / Random teacher token IDs (LongTensor)
                - 'teacher_attention_mask': 教师注意力掩码 (LongTensor)
                  / Teacher attention mask (LongTensor)
        """
        # 生成随机序列长度（模拟真实数据的变长特性）
        # Generate random sequence length (simulating variable-length nature of real data)
        actual_len = random.randint(self.seq_len // 2, self.seq_len)

        # 学生 input_ids 和 attention_mask / Student input_ids and attention_mask
        input_ids = torch.randint(0, self.vocab_size, (self.seq_len,), dtype=torch.long)
        attention_mask = torch.zeros(self.seq_len, dtype=torch.long)
        attention_mask[:actual_len] = 1

        # 创建 labels: 向左移一位，pad 位置设为 -100
        # Create labels: shift left by one, set pad positions to -100
        labels = input_ids.clone()
        labels[:-1] = input_ids[1:]
        labels[-1] = -100
        labels = labels.masked_fill(attention_mask == 0, -100)

        # 教师 input_ids 和 attention_mask / Teacher input_ids and attention_mask
        teacher_input_ids = torch.randint(0, self.vocab_size, (self.seq_len,), dtype=torch.long)
        teacher_attention_mask = torch.zeros(self.seq_len, dtype=torch.long)
        teacher_attention_mask[:actual_len] = 1

        # 随机图像张量（模拟归一化后的图像数据）
        # Random image tensor (simulating normalized image data)
        pixel_values = torch.randn(3, self.image_size, self.image_size, dtype=torch.float)

        return {
            'input_ids': input_ids,
            'attention_mask': attention_mask,
            'labels': labels,
            'pixel_values': pixel_values,
            'teacher_input_ids': teacher_input_ids,
            'teacher_attention_mask': teacher_attention_mask,
        }


def create_dataloader(
    dataset: Dataset,
    batch_size: int,
    num_workers: int = 4,
    shuffle: bool = True,
) -> DataLoader:
    """创建数据加载器的工厂函数。 / Factory function to create data loader.

    根据给定的数据集和参数创建 PyTorch DataLoader。
    / Create a PyTorch DataLoader based on the given dataset and parameters.

    Args:
        dataset: 数据集实例（MultimodalDistillDataset 或 DummyDistillDataset）
                / Dataset instance (MultimodalDistillDataset or DummyDistillDataset)
        batch_size: 每个 batch 的样本数量 / Number of samples per batch
        num_workers: 数据加载的工作进程数，默认为 4 / Number of data loading workers, default 4
        shuffle: 是否在每个 epoch 开始时打乱数据，默认为 True
                 / Whether to shuffle data at the start of each epoch, default True

    Returns:
        配置好的 PyTorch DataLoader 实例 / Configured PyTorch DataLoader instance
    """
    dataloader = DataLoader(
        dataset,
        batch_size=batch_size,
        shuffle=shuffle,
        num_workers=num_workers,
        pin_memory=True,
        drop_last=False,
    )
    return dataloader

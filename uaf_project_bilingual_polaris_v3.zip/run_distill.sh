#!/bin/bash
# UAF 多模态蒸馏一键启动脚本
# 
# 使用方法:
#   chmod +x run_distill.sh
#   ./run_distill.sh
#
# 或者带参数:
#   ./run_distill.sh --config custom_config.yaml --stage 0

set -e  # 遇到错误立即退出

echo "=========================================="
echo "UAF 多模态蒸馏训练启动脚本"
echo "=========================================="
echo ""

# 默认配置
CONFIG_FILE="trainer/distill_config.yaml"
RESUME_CHECKPOINT=""
START_STAGE=""

# 解析参数
while [[ $# -gt 0 ]]; do
    case $1 in
        --config)
            CONFIG_FILE="$2"
            shift 2
            ;;
        --resume)
            RESUME_CHECKPOINT="$2"
            shift 2
            ;;
        --stage)
            START_STAGE="$2"
            shift 2
            ;;
        --help)
            echo "使用方法: $0 [选项]"
            echo ""
            echo "选项:"
            echo "  --config <path>     配置文件路径 (默认: trainer/distill_config.yaml)"
            echo "  --resume <path>     从检查点恢复训练"
            echo "  --stage <num>       从指定阶段开始 (0=文本, 1=融合, 2=端到端)"
            echo "  --help              显示此帮助信息"
            echo ""
            echo "示例:"
            echo "  $0"
            echo "  $0 --config my_config.yaml"
            echo "  $0 --resume outputs/checkpoint-1000.pt"
            echo "  $0 --stage 1"
            exit 0
            ;;
        *)
            echo "未知参数: $1"
            echo "使用 --help 查看帮助"
            exit 1
            ;;
    esac
done

# 检查 Python 环境
echo "[1/5] 检查 Python 环境..."
if ! command -v python3 &> /dev/null; then
    echo "错误: 未找到 python3"
    exit 1
fi

PYTHON_VERSION=$(python3 --version 2>&1 | awk '{print $2}')
echo "  Python 版本: $PYTHON_VERSION"

# 检查 CUDA
echo ""
echo "[2/5] 检查 CUDA 环境..."
if command -v nvidia-smi &> /dev/null; then
    echo "  CUDA 可用:"
    nvidia-smi --query-gpu=name,memory.total,memory.free --format=csv,noheader
else
    echo "  警告: 未检测到 CUDA，将使用 CPU 训练（非常慢）"
fi

# 检查依赖
echo ""
echo "[3/5] 检查依赖包..."
REQUIRED_PACKAGES="torch transformers modelscope pyyaml tqdm numpy"
MISSING_PACKAGES=""

for package in $REQUIRED_PACKAGES; do
    if ! python3 -c "import $package" 2>/dev/null; then
        MISSING_PACKAGES="$MISSING_PACKAGES $package"
    fi
done

if [ -n "$MISSING_PACKAGES" ]; then
    echo "  缺少依赖包:$MISSING_PACKAGES"
    echo "  正在安装..."
    pip install -q $MISSING_PACKAGES
else
    echo "  所有依赖包已安装"
fi

# 检查配置文件
echo ""
echo "[4/5] 检查配置文件..."
if [ ! -f "$CONFIG_FILE" ]; then
    echo "  错误: 配置文件不存在: $CONFIG_FILE"
    exit 1
fi
echo "  配置文件: $CONFIG_FILE"

# 创建输出目录
echo ""
echo "[5/5] 准备输出目录..."
OUTPUT_DIR=$(python3 -c "import yaml; print(yaml.safe_load(open('$CONFIG_FILE'))['output']['output_dir'])")
mkdir -p "$OUTPUT_DIR"
mkdir -p "logs"
echo "  输出目录: $OUTPUT_DIR"

# 构建命令
echo ""
echo "=========================================="
echo "启动训练"
echo "=========================================="

CMD="python3 trainer/train_distill.py --config $CONFIG_FILE"

if [ -n "$RESUME_CHECKPOINT" ]; then
    CMD="$CMD --resume $RESUME_CHECKPOINT"
    echo "  恢复训练: $RESUME_CHECKPOINT"
fi

if [ -n "$START_STAGE" ]; then
    CMD="$CMD --stage $START_STAGE"
    echo "  起始阶段: $START_STAGE"
fi

echo ""
echo "执行命令: $CMD"
echo ""

# 运行训练
$CMD 2>&1 | tee "logs/training_$(date +%Y%m%d_%H%M%S).log"

# 检查训练结果
echo ""
echo "=========================================="
if [ ${PIPESTATUS[0]} -eq 0 ]; then
    echo "训练完成!"
    echo ""
    echo "输出文件:"
    ls -lh "$OUTPUT_DIR"
else
    echo "训练失败，请检查日志"
    exit 1
fi

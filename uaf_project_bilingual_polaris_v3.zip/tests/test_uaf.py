"""
UAF (Unnormalized Attention Flow) 单元测试 / UAF (Unnormalized Attention Flow) Unit Tests

测试内容 / Test contents:
1. UAF_StateIntegrator 的 forward 输出形状 / UAF_StateIntegrator forward output shape
2. inference_step 返回的状态向量正确更新 / inference_step returns correctly updated state vector
3. 状态向量的范数随 token 累积而单调非递减 / State vector norm is monotonically non-decreasing as tokens accumulate
4. forward 和 inference_step 产生的最终状态一致 / forward and inference_step produce consistent final states
"""

import torch
import pytest
import sys
import os

# 添加父目录到路径以支持导入 / Add parent directory to path for imports
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from model.uaf_attention import UAF_StateIntegrator


class TestUAFStateIntegrator:
    """UAF_StateIntegrator 的单元测试类。 / Unit test class for UAF_StateIntegrator."""

    @pytest.fixture
    def sample_config(self):
        """提供标准测试配置。 / Provide standard test configuration."""
        return {
            'batch_size': 2,
            'seq_len': 10,
            'd_model': 64,
            'eta': 1.0
        }

    @pytest.fixture
    def uaf_module(self, sample_config):
        """创建 UAF 模块实例。 / Create UAF module instance."""
        return UAF_StateIntegrator(
            d_model=sample_config['d_model'],
            eta=sample_config['eta'],
            activation='relu'
        )

    @pytest.fixture
    def sample_input(self, sample_config):
        """生成随机测试输入。 / Generate random test input."""
        torch.manual_seed(42)
        return torch.randn(
            sample_config['batch_size'],
            sample_config['seq_len'],
            sample_config['d_model']
        )

    def test_forward_output_shape(self, uaf_module, sample_input, sample_config):
        """
        测试 forward 方法的输出形状。 / Test forward method output shape.

        验证 / Verify:
        - 输入: (batch, seq_len, d_model) / Input: (batch, seq_len, d_model)
        - 输出: (batch, seq_len, d_model) / Output: (batch, seq_len, d_model)
        """
        batch_size = sample_config['batch_size']
        seq_len = sample_config['seq_len']
        d_model = sample_config['d_model']

        output = uaf_module(sample_input)

        assert output.shape == (batch_size, seq_len, d_model), \
            f"Expected shape {(batch_size, seq_len, d_model)}, got {output.shape}"

    def test_inference_step_state_update(self, uaf_module, sample_config):
        """
        测试 inference_step 方法正确更新状态。 / Test inference_step method correctly updates state.

        验证 / Verify:
        - 初始状态为 None 时，模块能正确处理
          / When initial state is None, the module handles it correctly
        - 返回的输出和状态形状正确 / Returned output and state shapes are correct
        - 状态确实被更新（不是简单的复制） / State is actually updated (not simply copied)
        """
        batch_size = sample_config['batch_size']
        d_model = sample_config['d_model']

        # 创建单个 token 输入 / Create single token input
        token = torch.randn(batch_size, d_model)

        # 第一次调用（state=None） / First call (state=None)
        output1, state1 = uaf_module.inference_step(token, state=None)

        assert output1.shape == (batch_size, d_model), \
            f"Expected output shape {(batch_size, d_model)}, got {output1.shape}"
        assert state1.shape == (batch_size, d_model), \
            f"Expected state shape {(batch_size, d_model)}, got {state1.shape}"

        # 第二次调用（使用上一步的状态） / Second call (using previous state)
        token2 = torch.randn(batch_size, d_model)
        output2, state2 = uaf_module.inference_step(token2, state=state1)

        assert state2.shape == (batch_size, d_model), \
            f"Expected state shape {(batch_size, d_model)}, got {state2.shape}"

        # 验证状态确实被更新了 / Verify state was actually updated
        state_diff = torch.abs(state2 - state1).max().item()
        assert state_diff > 1e-6, \
            f"State was not updated, max difference: {state_diff}"

    def test_state_norm_monotonicity(self, uaf_module, sample_config):
        """
        测试状态向量的范数随 token 累积而单调非递减。
        / Test state vector norm is monotonically non-decreasing as tokens accumulate.

        验证 / Verify:
        - 由于 α(q, k) ≥ 0（ReLU 激活），状态范数应该单调非递减
          / Since α(q, k) ≥ 0 (ReLU activation), state norm should be monotonically non-decreasing
        - 记录每个 step 的状态范数，验证单调性
          / Record state norm at each step, verify monotonicity
        """
        batch_size = sample_config['batch_size']
        seq_len = sample_config['seq_len']
        d_model = sample_config['d_model']

        # 生成随机输入序列 / Generate random input sequence
        torch.manual_seed(42)
        x = torch.randn(batch_size, seq_len, d_model)

        # 使用 inference_step 逐步处理，记录原始状态范数
        # Use inference_step to process step by step, record raw state norms
        state = None
        state_norms = []

        with torch.no_grad():
            for i in range(seq_len):
                token = x[:, i, :]

                # 手动计算状态更新以获取原始状态（在 LayerNorm 之前）
                # Manually compute state update to get raw state (before LayerNorm)
                q = uaf_module.W_q(token)
                k = uaf_module.W_k(token)
                v = uaf_module.W_v(token)

                intensity = uaf_module.intensity(q, k)

                if state is None:
                    state = torch.zeros(batch_size, d_model)

                state_update = uaf_module.eta * intensity.unsqueeze(-1) * v
                state = state + state_update

                # 记录原始状态范数 / Record raw state norm
                state_norm = state.norm(dim=-1).mean().item()
                state_norms.append(state_norm)

        # 验证单调非递减 / Verify monotonic non-decreasing
        violations = 0
        for i in range(len(state_norms) - 1):
            if state_norms[i] > state_norms[i + 1] + 1e-6:  # 允许微小数值误差 / Allow tiny numerical error
                violations += 1

        assert violations == 0, \
            f"State norm is not monotonically non-decreasing. " \
            f"Found {violations} violations. Norms: {state_norms}"

    def test_forward_inference_equivalence(self, uaf_module, sample_config):
        """
        测试 forward 和 inference_step 产生的最终状态一致。
        / Test forward and inference_step produce consistent final states.

        验证 / Verify:
        - forward（向量化）和 inference_step（循环）在数学上等价
          / forward (vectorized) and inference_step (loop) are mathematically equivalent
        - 两种方法产生的最终状态差异小于阈值
          / Final state difference between the two methods is below threshold
        """
        batch_size = sample_config['batch_size']
        seq_len = sample_config['seq_len']
        d_model = sample_config['d_model']

        # 生成随机输入 / Generate random input
        torch.manual_seed(42)
        x = torch.randn(batch_size, seq_len, d_model)

        # 方法 1: 使用 forward / Method 1: Use forward
        uaf_module.eval()
        with torch.no_grad():
            output_vectorized = uaf_module(x)
        final_state_vectorized = output_vectorized[:, -1, :]

        # 方法 2: 使用 inference_step / Method 2: Use inference_step
        state = None
        with torch.no_grad():
            for i in range(seq_len):
                token = x[:, i, :]
                output, state = uaf_module.inference_step(token, state)
        final_state_sequential = output

        # 比较两种方法的最终状态 / Compare final states from both methods
        diff = torch.abs(final_state_vectorized - final_state_sequential).max().item()

        tolerance = 1e-5
        assert diff < tolerance, \
            f"Forward and inference_step produce different results. " \
            f"Max difference: {diff:.2e} (tolerance: {tolerance})"

    def test_intensity_non_negative(self, uaf_module, sample_config):
        """
        测试强度函数 α(q, k) 始终非负。 / Test intensity function α(q, k) is always non-negative.

        验证 / Verify:
        - 对于任意输入，intensity() 返回的值都应该 ≥ 0
          / For any input, intensity() should return values ≥ 0
        - 这是因为使用了 ReLU/SiLU 激活函数
          / This is because ReLU/SiLU activation functions are used
        """
        batch_size = sample_config['batch_size']
        d_model = sample_config['d_model']

        # 测试多种随机输入 / Test multiple random inputs
        torch.manual_seed(42)
        for _ in range(10):
            q = torch.randn(batch_size, d_model)
            k = torch.randn(batch_size, d_model)

            intensity = uaf_module.intensity(q, k)

            assert (intensity >= 0).all(), \
                f"Intensity should be non-negative, got min: {intensity.min().item()}"

    def test_initial_state_zero(self, uaf_module, sample_config):
        """
        测试初始状态为零向量。 / Test initial state is zero vector.

        验证 / Verify:
        - reset_state() 方法返回零向量 / reset_state() returns zero vector
        - 符合论文定义 z_0 = 0 / Consistent with paper definition z_0 = 0
        """
        batch_size = sample_config['batch_size']
        d_model = sample_config['d_model']

        device = torch.device('cpu')
        dtype = torch.float32

        initial_state = uaf_module.reset_state(batch_size, device, dtype)

        assert initial_state.shape == (batch_size, d_model), \
            f"Expected shape {(batch_size, d_model)}, got {initial_state.shape}"

        assert torch.allclose(initial_state, torch.zeros_like(initial_state)), \
            "Initial state should be zero vector"

    def test_different_activations(self, sample_config):
        """
        测试不同激活函数（ReLU 和 SiLU）都能正常工作。
        / Test that different activation functions (ReLU and SiLU) both work correctly.
        """
        batch_size = sample_config['batch_size']
        seq_len = sample_config['seq_len']
        d_model = sample_config['d_model']

        torch.manual_seed(42)
        x = torch.randn(batch_size, seq_len, d_model)

        for activation in ['relu', 'silu']:
            uaf = UAF_StateIntegrator(
                d_model=d_model,
                eta=1.0,
                activation=activation
            )
            uaf.eval()

            with torch.no_grad():
                output = uaf(x)

            assert output.shape == (batch_size, seq_len, d_model), \
                f"Activation {activation}: incorrect output shape"

            # 验证输出不是 NaN 或 Inf / Verify output is not NaN or Inf
            assert not torch.isnan(output).any(), \
                f"Activation {activation}: output contains NaN"
            assert not torch.isinf(output).any(), \
                f"Activation {activation}: output contains Inf"

    def test_batch_independence(self, uaf_module, sample_config):
        """
        测试批次中的样本相互独立。 / Test samples in a batch are independent.

        验证 / Verify:
        - 批次中一个样本的变化不影响其他样本
          / A change in one sample in the batch does not affect other samples
        """
        batch_size = sample_config['batch_size']
        seq_len = sample_config['seq_len']
        d_model = sample_config['d_model']

        torch.manual_seed(42)
        x1 = torch.randn(batch_size, seq_len, d_model)

        # 修改最后一个样本 / Modify the last sample
        x2 = x1.clone()
        x2[-1] = torch.randn(seq_len, d_model) * 10  # 大幅修改 / Significantly modify

        uaf_module.eval()
        with torch.no_grad():
            output1 = uaf_module(x1)
            output2 = uaf_module(x2)

        # 前 batch_size-1 个样本应该相同 / First batch_size-1 samples should be identical
        for i in range(batch_size - 1):
            assert torch.allclose(output1[i], output2[i], atol=1e-6), \
                f"Sample {i} was affected by changes to another sample"

        # 最后一个样本应该不同 / Last sample should be different
        assert not torch.allclose(output1[-1], output2[-1]), \
            "Modified sample should produce different output"


class TestUAFStateIntegratorEdgeCases:
    """UAF_StateIntegrator 的边界情况测试。 / Edge case tests for UAF_StateIntegrator."""

    def test_single_token_sequence(self):
        """测试单 token 序列。 / Test single token sequence."""
        uaf = UAF_StateIntegrator(d_model=32, eta=1.0)
        x = torch.randn(2, 1, 32)  # (batch=2, seq_len=1, d_model=32)

        output = uaf(x)
        assert output.shape == (2, 1, 32)

    def test_large_d_model(self):
        """测试大维度模型。 / Test large dimension model."""
        uaf = UAF_StateIntegrator(d_model=1024, eta=1.0)
        x = torch.randn(2, 5, 1024)

        output = uaf(x)
        assert output.shape == (2, 5, 1024)

    def test_small_eta(self):
        """测试小的 eta 值。 / Test small eta value."""
        uaf = UAF_StateIntegrator(d_model=64, eta=0.01)
        x = torch.randn(2, 10, 64)

        output = uaf(x)
        assert output.shape == (2, 10, 64)
        assert not torch.isnan(output).any()

    def test_inference_step_3d_input(self):
        """测试 inference_step 处理 3D 输入 (batch, 1, d_model)。 / Test inference_step with 3D input (batch, 1, d_model)."""
        uaf = UAF_StateIntegrator(d_model=64, eta=1.0)

        # 3D 输入 / 3D input
        x_3d = torch.randn(2, 1, 64)
        output, state = uaf.inference_step(x_3d, state=None)

        assert output.shape == (2, 64)
        assert state.shape == (2, 64)


if __name__ == "__main__":
    pytest.main([__file__, "-v"])

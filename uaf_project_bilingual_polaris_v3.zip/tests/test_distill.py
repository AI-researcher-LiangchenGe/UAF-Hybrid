"""
蒸馏相关单元测试 / Distillation-related unit tests

测试内容 / Test contents:
    1. 学生模型前向传播的形状正确性 / Student model forward pass shape correctness
    2. 蒸馏损失函数的输出范围 / Distillation loss function output range
    3. 模型保存和加载的完整性（三种格式） / Model save and load integrity (three formats)

Author: AI Assistant
Date: 2026-05-26
"""

import torch
import pytest
import sys
import os
import tempfile
import shutil
from pathlib import Path

# 添加项目根目录到路径 / Add project root directory to path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from model.student_model import (
    VisionEncoder, CrossAttentionFusion, GatedFusion,
    MultimodalUAFStudent, create_student_model
)
from model.distill_loss import (
    KLDistillationLoss, FeatureAlignmentLoss, TaskLoss,
    DistillationLoss, TemperatureScheduler
)


# ==================== Fixtures ====================

@pytest.fixture
def device():
    """提供测试设备 / Provide test device."""
    return torch.device('cuda' if torch.cuda.is_available() else 'cpu')


@pytest.fixture
def dummy_vision_backbone():
    """创建 dummy 视觉骨干模型（模拟 DINOv3） / Create dummy vision backbone (simulating DINOv3)."""
    class DummyVisionBackbone(torch.nn.Module):
        def __init__(self):
            super().__init__()
            self.output_dim = 384

        def forward(self, pixel_values):
            batch_size = pixel_values.size(0)
            # 模拟输出 pooler_output / Simulate pooler_output
            class MockOutput:
                def __init__(self, pooler_output):
                    self.pooler_output = pooler_output

            pooler_output = torch.randn(batch_size, self.output_dim)
            return MockOutput(pooler_output)

    return DummyVisionBackbone()


@pytest.fixture
def student_config():
    """提供测试配置 / Provide test configuration."""
    return {
        'student_model': {
            'vision_encoder': {
                'input_dim': 384,
                'hidden_dim': 512,
                'output_dim': 512,
                'freeze': True
            },
            'text_encoder': {
                'd_model': 512,
                'n_layers': 6,
                'eta': 1.0,
                'activation': 'relu'
            },
            'fusion': {
                'type': 'cross_attention'
            },
            'output_head': {
                'vocab_size': 1000  # 测试时使用小词汇表 / Use small vocabulary for testing
            }
        },
        'data': {
            'train_dataset': {
                'max_seq_length': 128
            }
        }
    }


@pytest.fixture
def sample_batch(device):
    """提供测试用的样本批次数据 / Provide sample batch data for testing."""
    batch_size = 4
    seq_len = 32
    vocab_size = 1000

    return {
        'input_ids': torch.randint(0, vocab_size, (batch_size, seq_len)).to(device),
        'pixel_values': torch.randn(batch_size, 3, 224, 224).to(device),
        'attention_mask': torch.ones(batch_size, seq_len).to(device),
        'labels': torch.randint(0, vocab_size, (batch_size, seq_len)).to(device)
    }


# ==================== 学生模型测试 / Student Model Tests ====================

class TestVisionEncoder:
    """测试视觉编码器模块 / Test vision encoder module."""

    def test_output_shape(self, dummy_vision_backbone, device):
        """测试输出形状是否正确 / Test whether output shape is correct."""
        encoder = VisionEncoder(
            backbone=dummy_vision_backbone,
            input_dim=384,
            hidden_dim=512,
            output_dim=512,
            freeze=True
        ).to(device)

        batch_size = 4
        pixel_values = torch.randn(batch_size, 3, 224, 224).to(device)

        output = encoder(pixel_values)

        assert output.shape == (batch_size, 512), f"期望形状 (4, 512)，实际 {output.shape}"

    def test_freeze_backbone(self, dummy_vision_backbone):
        """测试骨干网络是否被正确冻结 / Test whether backbone is correctly frozen."""
        encoder = VisionEncoder(
            backbone=dummy_vision_backbone,
            freeze=True
        )

        for param in encoder.backbone.parameters():
            assert not param.requires_grad, "骨干网络参数应被冻结 / Backbone parameters should be frozen"

    def test_projection_trainable(self, dummy_vision_backbone, device):
        """测试投影层是否可训练 / Test whether projection layer is trainable."""
        encoder = VisionEncoder(
            backbone=dummy_vision_backbone,
            freeze=True
        ).to(device)

        for param in encoder.projection.parameters():
            assert param.requires_grad, "投影层参数应可训练 / Projection layer parameters should be trainable"


class TestCrossAttentionFusion:
    """测试交叉注意力融合模块 / Test cross-attention fusion module."""

    def test_output_shape(self, device):
        """测试输出形状是否正确 / Test whether output shape is correct."""
        fusion = CrossAttentionFusion(d_model=512, n_heads=8).to(device)

        batch_size = 4
        vision_features = torch.randn(batch_size, 512).to(device)
        text_features = torch.randn(batch_size, 32, 512).to(device)

        output = fusion(vision_features, text_features)

        assert output.shape == (batch_size, 512), f"期望形状 (4, 512)，实际 {output.shape}"

    def test_with_mask(self, device):
        """测试带掩码的前向传播 / Test forward pass with mask."""
        fusion = CrossAttentionFusion(d_model=512, n_heads=8).to(device)

        batch_size = 4
        seq_len = 32
        vision_features = torch.randn(batch_size, 512).to(device)
        text_features = torch.randn(batch_size, seq_len, 512).to(device)
        mask = torch.ones(batch_size, seq_len).to(device)
        mask[:, 16:] = 0  # 后半部分掩码 / Mask the second half

        output = fusion(vision_features, text_features, mask)

        assert output.shape == (batch_size, 512)
        assert not torch.isnan(output).any(), "输出不应包含 NaN / Output should not contain NaN"


class TestGatedFusion:
    """测试门控融合模块 / Test gated fusion module."""

    def test_output_shape(self, device):
        """测试输出形状是否正确 / Test whether output shape is correct."""
        fusion = GatedFusion(d_model=512).to(device)

        batch_size = 4
        vision_features = torch.randn(batch_size, 512).to(device)
        text_features = torch.randn(batch_size, 512).to(device)

        output = fusion(vision_features, text_features)

        assert output.shape == (batch_size, 512)

    def test_gate_range(self, device):
        """测试门控权重是否在 [0, 1] 范围内 / Test whether gate weights are in [0, 1] range."""
        fusion = GatedFusion(d_model=512).to(device)

        batch_size = 4
        vision_features = torch.randn(batch_size, 512).to(device)
        text_features = torch.randn(batch_size, 512).to(device)

        # 手动计算门控值 / Manually compute gate values
        concat = torch.cat([vision_features, text_features], dim=-1)
        gate = fusion.gate(concat)

        assert (gate >= 0).all() and (gate <= 1).all(), "门控值应在 [0, 1] 范围内 / Gate values should be in [0, 1] range"


class TestMultimodalUAFStudent:
    """测试多模态学生模型 / Test multimodal UAF student model."""

    def test_forward_output_shapes(self, dummy_vision_backbone, student_config, device):
        """测试前向传播的输出形状 / Test forward pass output shapes."""
        student = create_student_model(dummy_vision_backbone, student_config).to(device)

        batch_size = 4
        seq_len = 32
        vocab_size = student_config['student_model']['output_head']['vocab_size']

        input_ids = torch.randint(0, vocab_size, (batch_size, seq_len)).to(device)
        pixel_values = torch.randn(batch_size, 3, 224, 224).to(device)

        outputs = student(input_ids=input_ids, pixel_values=pixel_values)

        # 检查各输出形状 / Check output shapes
        assert 'logits' in outputs
        assert outputs['logits'].shape == (batch_size, seq_len, vocab_size)
        assert 'vision_features' in outputs
        assert outputs['vision_features'].shape == (batch_size, 512)
        assert 'text_features' in outputs
        assert outputs['text_features'].shape == (batch_size, seq_len, 512)

    def test_forward_text_only(self, dummy_vision_backbone, student_config, device):
        """测试仅文本输入的前向传播 / Test forward pass with text-only input."""
        student = create_student_model(dummy_vision_backbone, student_config).to(device)

        batch_size = 4
        seq_len = 32
        vocab_size = student_config['student_model']['output_head']['vocab_size']

        input_ids = torch.randint(0, vocab_size, (batch_size, seq_len)).to(device)

        outputs = student(input_ids=input_ids)

        assert 'logits' in outputs
        assert outputs['logits'].shape == (batch_size, seq_len, vocab_size)

    def test_forward_vision_only(self, dummy_vision_backbone, student_config, device):
        """测试仅视觉输入的前向传播 / Test forward pass with vision-only input."""
        student = create_student_model(dummy_vision_backbone, student_config).to(device)

        batch_size = 4
        pixel_values = torch.randn(batch_size, 3, 224, 224).to(device)

        outputs = student(pixel_values=pixel_values)

        # 仅视觉输入时不应有 logits / No logits when vision-only input
        assert 'logits' not in outputs
        assert 'vision_features' in outputs

    def test_loss_computation(self, dummy_vision_backbone, student_config, device):
        """测试损失计算 / Test loss computation."""
        student = create_student_model(dummy_vision_backbone, student_config).to(device)

        batch_size = 4
        seq_len = 32
        vocab_size = student_config['student_model']['output_head']['vocab_size']

        input_ids = torch.randint(0, vocab_size, (batch_size, seq_len)).to(device)
        labels = torch.randint(0, vocab_size, (batch_size, seq_len)).to(device)

        outputs = student(input_ids=input_ids, labels=labels)

        assert 'loss' in outputs
        assert outputs['loss'].dim() == 0, "损失应为标量 / Loss should be a scalar"
        assert outputs['loss'] >= 0, "损失应为非负数 / Loss should be non-negative"

    def test_generate(self, dummy_vision_backbone, student_config, device):
        """测试生成方法 / Test generation method."""
        student = create_student_model(dummy_vision_backbone, student_config).to(device)
        student.eval()

        batch_size = 2
        pixel_values = torch.randn(batch_size, 3, 224, 224).to(device)

        generated = student.generate(
            pixel_values=pixel_values,
            max_new_tokens=10,
            do_sample=False
        )

        assert generated.shape[0] == batch_size
        assert generated.shape[1] > 1  # 至少生成了一些 token / At least some tokens generated

    def test_freeze_methods(self, dummy_vision_backbone, student_config, device):
        """测试冻结/解冻方法 / Test freeze/unfreeze methods."""
        student = create_student_model(dummy_vision_backbone, student_config).to(device)

        # 测试冻结视觉编码器 / Test freezing vision encoder
        student.freeze_vision_encoder()
        for param in student.vision_encoder.parameters():
            assert not param.requires_grad

        # 测试解冻所有 / Test unfreezing all
        student.unfreeze_all()
        for param in student.parameters():
            assert param.requires_grad


# ==================== 损失函数测试 / Loss Function Tests ====================

class TestKLDistillationLoss:
    """测试 KL 散度蒸馏损失 / Test KL divergence distillation loss."""

    def test_output_range(self, device):
        """测试输出范围 / Test output range."""
        loss_fn = KLDistillationLoss(temperature=2.0).to(device)

        batch_size = 4
        seq_len = 32
        vocab_size = 1000

        student_logits = torch.randn(batch_size, seq_len, vocab_size).to(device)
        teacher_logits = torch.randn(batch_size, seq_len, vocab_size).to(device)

        loss = loss_fn(student_logits, teacher_logits)

        assert loss.dim() == 0, "损失应为标量 / Loss should be a scalar"
        assert loss >= 0, "KL 散度应为非负数 / KL divergence should be non-negative"

    def test_with_mask(self, device):
        """测试带掩码的损失计算 / Test loss computation with mask."""
        loss_fn = KLDistillationLoss(temperature=2.0).to(device)

        batch_size = 4
        seq_len = 32
        vocab_size = 1000

        student_logits = torch.randn(batch_size, seq_len, vocab_size).to(device)
        teacher_logits = torch.randn(batch_size, seq_len, vocab_size).to(device)
        mask = torch.ones(batch_size, seq_len).to(device)
        mask[:, 16:] = 0

        loss = loss_fn(student_logits, teacher_logits, mask)

        assert loss >= 0
        assert not torch.isnan(loss)


class TestFeatureAlignmentLoss:
    """测试特征对齐损失 / Test feature alignment loss."""

    @pytest.mark.parametrize("distance", ['mse', 'l2', 'cosine', 'huber'])
    def test_distance_metrics(self, distance, device):
        """测试不同距离度量 / Test different distance metrics."""
        loss_fn = FeatureAlignmentLoss(distance=distance).to(device)

        batch_size = 4
        seq_len = 32
        dim = 512

        student_features = torch.randn(batch_size, seq_len, dim).to(device)
        teacher_features = torch.randn(batch_size, seq_len, dim).to(device)

        loss = loss_fn(student_features, teacher_features)

        assert loss.dim() == 0
        assert loss >= 0

    def test_identical_features(self, device):
        """测试相同特征的损失应为 0 / Test loss should be 0 for identical features."""
        loss_fn = FeatureAlignmentLoss(distance='mse').to(device)

        batch_size = 4
        seq_len = 32
        dim = 512

        features = torch.randn(batch_size, seq_len, dim).to(device)

        loss = loss_fn(features, features)

        assert loss.item() < 1e-6, "相同特征的 MSE 损失应接近 0 / MSE loss for identical features should be near 0"


class TestTaskLoss:
    """测试任务损失 / Test task loss."""

    def test_output_range(self, device):
        """测试输出范围 / Test output range."""
        loss_fn = TaskLoss().to(device)

        batch_size = 4
        seq_len = 32
        vocab_size = 1000

        logits = torch.randn(batch_size, seq_len, vocab_size).to(device)
        labels = torch.randint(0, vocab_size, (batch_size, seq_len)).to(device)

        loss = loss_fn(logits, labels)

        assert loss.dim() == 0
        assert loss >= 0

    def test_ignore_index(self, device):
        """测试忽略索引 / Test ignore index."""
        loss_fn = TaskLoss(ignore_index=-100).to(device)

        batch_size = 4
        seq_len = 32
        vocab_size = 1000

        logits = torch.randn(batch_size, seq_len, vocab_size).to(device)
        labels = torch.randint(0, vocab_size, (batch_size, seq_len)).to(device)
        labels[:, 16:] = -100  # 部分标签设为忽略 / Set some labels to ignore

        loss = loss_fn(logits, labels)

        assert loss >= 0
        assert not torch.isnan(loss)


class TestDistillationLoss:
    """测试组合蒸馏损失 / Test combined distillation loss."""

    def test_combined_loss(self, device):
        """测试组合损失计算 / Test combined loss computation."""
        loss_fn = DistillationLoss(
            temperature=2.0,
            kl_weight=1.0,
            feature_weight=0.5,
            task_weight=0.3
        ).to(device)

        batch_size = 4
        seq_len = 32
        vocab_size = 1000
        dim = 512

        student_outputs = {
            'logits': torch.randn(batch_size, seq_len, vocab_size).to(device),
            'text_features': torch.randn(batch_size, seq_len, dim).to(device)
        }

        teacher_outputs = {
            'logits': torch.randn(batch_size, seq_len, vocab_size).to(device),
            'hidden_states': [torch.randn(batch_size, seq_len, dim).to(device) for _ in range(3)]
        }

        labels = torch.randint(0, vocab_size, (batch_size, seq_len)).to(device)

        total_loss, loss_dict = loss_fn(student_outputs, teacher_outputs, labels)

        assert total_loss.dim() == 0
        assert 'kl_loss' in loss_dict
        assert 'feature_loss' in loss_dict
        assert 'task_loss' in loss_dict
        assert 'total_loss' in loss_dict


class TestTemperatureScheduler:
    """测试温度调度器 / Test temperature scheduler."""

    def test_linear_schedule(self):
        """测试线性调度 / Test linear schedule."""
        scheduler = TemperatureScheduler(
            initial_temp=2.0,
            final_temp=1.0,
            warmup_steps=100,
            strategy='linear'
        )

        # 初始温度 / Initial temperature
        assert abs(scheduler.get_current_temp() - 2.0) < 1e-6

        # 经过一半步数 / After half the steps
        for _ in range(50):
            scheduler.step()

        temp = scheduler.get_current_temp()
        assert 1.0 < temp < 2.0, f"中间温度应在 1.0 和 2.0 之间，实际 {temp}"

        # 经过所有步数 / After all steps
        for _ in range(50):
            scheduler.step()

        assert abs(scheduler.get_current_temp() - 1.0) < 1e-6


# ==================== 模型保存/加载测试 / Model Save/Load Tests ====================

class TestModelSaveLoad:
    """测试模型保存和加载 / Test model save and load."""

    def test_pytorch_save_load(self, dummy_vision_backbone, student_config, device):
        """测试 PyTorch 格式保存和加载 / Test PyTorch format save and load."""
        student = create_student_model(dummy_vision_backbone, student_config).to(device)

        # 创建临时目录 / Create temporary directory
        with tempfile.TemporaryDirectory() as tmpdir:
            save_path = Path(tmpdir) / "model.pt"

            # 保存 / Save
            torch.save(student.state_dict(), save_path)

            # 加载 / Load
            new_student = create_student_model(dummy_vision_backbone, student_config).to(device)
            state_dict = torch.load(save_path, map_location=device)
            new_student.load_state_dict(state_dict)

            # 验证参数相同 / Verify parameters are identical
            for (n1, p1), (n2, p2) in zip(student.named_parameters(), new_student.named_parameters()):
                assert n1 == n2
                assert torch.allclose(p1, p2), f"参数 {n1} 不匹配 / Parameter {n1} mismatch"

    def test_safetensors_save_load(self, dummy_vision_backbone, student_config, device):
        """测试 safetensors 格式保存和加载 / Test safetensors format save and load."""
        pytest.importorskip("safetensors", reason="safetensors 未安装 / safetensors not installed")

        from safetensors.torch import save_file, load_file

        student = create_student_model(dummy_vision_backbone, student_config).to(device)

        with tempfile.TemporaryDirectory() as tmpdir:
            save_path = Path(tmpdir) / "model.safetensors"

            # 保存 / Save
            save_file(student.state_dict(), save_path)

            # 加载 / Load
            state_dict = load_file(save_path)
            new_student = create_student_model(dummy_vision_backbone, student_config).to(device)
            new_student.load_state_dict(state_dict)

            # 验证 / Verify
            for (n1, p1), (n2, p2) in zip(student.named_parameters(), new_student.named_parameters()):
                assert torch.allclose(p1, p2)


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
